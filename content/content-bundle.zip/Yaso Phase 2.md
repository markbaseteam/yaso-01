---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Création RAD par CS ^yu25IiMA

Activation Yaso Casting ^jIhFIvug

Intervention sociale ? ^6Epq17Qk

Validation Casting ^2oJnxCKw

Sortie ^bzzG9Lrg

Création RAD par AS ^WmdRCNqv

Création par API ^IrRMXmPW

N ^s9jme9sd

Y ^6uMnIGkW

Prescription ^lbgy1kUM

Ouverture de droits ^2bZLez38

Orientation ^8OTZt1nA

Génération d'une fiche-info ^8So0Ayyz

AS dispo ? ^adxiSTuz

Y ^bmPIrZgO

N ^Cz8VwmLx

Création par DAC ^QMCWbrz5

Création Prado ^oEOrHpYU

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.19",
	"elements": [
		{
			"type": "rectangle",
			"version": 484,
			"versionNonce": 129261030,
			"isDeleted": false,
			"id": "NzHyNbfrBXRmrgGjoAHQ-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -735.8787878787879,
			"y": -453.1515151515151,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 1809932539,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "yu25IiMA"
				},
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				}
			],
			"updated": 1678981195787,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 381,
			"versionNonce": 1119181690,
			"isDeleted": false,
			"id": "yu25IiMA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -721.6387900150183,
			"y": -448.1515151515151,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 145.52000427246094,
			"height": 48,
			"seed": 1670366901,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678981195787,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création RAD \npar CS",
			"rawText": "Création RAD par CS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "NzHyNbfrBXRmrgGjoAHQ-",
			"originalText": "Création RAD par CS"
		},
		{
			"type": "rectangle",
			"version": 569,
			"versionNonce": 686239034,
			"isDeleted": false,
			"id": "B_bFo4BTtkcueEW9N0oAP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -500.3333333333335,
			"y": -452.6363636363637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 979691963,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "WmdRCNqv"
				},
				{
					"id": "BFAM6_AIx2OJEsUH5EkDe",
					"type": "arrow"
				}
			],
			"updated": 1678981197875,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 466,
			"versionNonce": 509139814,
			"isDeleted": false,
			"id": "WmdRCNqv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -486.09333546956395,
			"y": -447.6363636363637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 145.52000427246094,
			"height": 48,
			"seed": 973333365,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678981197875,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création RAD \npar AS",
			"rawText": "Création RAD par AS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "B_bFo4BTtkcueEW9N0oAP",
			"originalText": "Création RAD par AS"
		},
		{
			"type": "rectangle",
			"version": 758,
			"versionNonce": 2005394342,
			"isDeleted": false,
			"id": "ZYXreMGpuENjDcit2qZdV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -2.999999999999659,
			"y": -457.6666666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 2131486683,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "IrRMXmPW"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				}
			],
			"updated": 1678980921169,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 696,
			"versionNonce": 269881786,
			"isDeleted": false,
			"id": "IrRMXmPW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 16.479995727539404,
			"y": -452.6666666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 135.04000854492188,
			"height": 48,
			"seed": 904615765,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921169,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création par \nAPI",
			"rawText": "Création par API",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ZYXreMGpuENjDcit2qZdV",
			"originalText": "Création par API"
		},
		{
			"type": "rectangle",
			"version": 1110,
			"versionNonce": 556900070,
			"isDeleted": false,
			"id": "h-dptHX8SFnNUiBMEdZjL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.515151515151,
			"y": 110.81818181818176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 867244282,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "oEOrHpYU"
				},
				{
					"id": "b9UoAtbwmNe5QRxebIemA",
					"type": "arrow"
				}
			],
			"updated": 1678982015226,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1042,
			"versionNonce": 2070456954,
			"isDeleted": false,
			"id": "oEOrHpYU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -572.9451594497214,
			"y": 127.81818181818176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 150.86001586914062,
			"height": 24,
			"seed": 1849985958,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678982015226,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création Prado",
			"rawText": "Création Prado",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "h-dptHX8SFnNUiBMEdZjL",
			"originalText": "Création Prado"
		},
		{
			"type": "rectangle",
			"version": 1587,
			"versionNonce": 249425850,
			"isDeleted": false,
			"id": "gxL-DKMyjIMlXMJhDjepf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -555.1212121212113,
			"y": -27.439393939393824,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 801448283,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "QMCWbrz5"
				},
				{
					"id": "oK-Zk-4GXqz1CZZOUgUk0",
					"type": "arrow"
				}
			],
			"updated": 1678981875531,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1523,
			"versionNonce": 1241874662,
			"isDeleted": false,
			"id": "QMCWbrz5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -535.6412163936723,
			"y": -22.439393939393824,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 135.04000854492188,
			"height": 48,
			"seed": 1939633621,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678981875531,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création par \nDAC",
			"rawText": "Création par DAC",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "gxL-DKMyjIMlXMJhDjepf",
			"originalText": "Création par DAC"
		},
		{
			"type": "rectangle",
			"version": 1305,
			"versionNonce": 1695362682,
			"isDeleted": false,
			"id": "svKVjGGJ-L36LKHMoRXSC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -91.53354978354963,
			"y": -2.9274891774895195,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 476426581,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "2bZLez38"
				},
				{
					"id": "Q3dWcUrpYCeifMjJPRcFs",
					"type": "arrow"
				},
				{
					"id": "g7X7bj1MM0cG4QezVgJnW",
					"type": "arrow"
				}
			],
			"updated": 1678981233208,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1216,
			"versionNonce": 545164838,
			"isDeleted": false,
			"id": "2bZLez38",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.73354673179182,
			"y": 2.0725108225104805,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 140.39999389648438,
			"height": 48,
			"seed": 185105019,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678981233208,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ouverture de \ndroits",
			"rawText": "Ouverture de droits",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "svKVjGGJ-L36LKHMoRXSC",
			"originalText": "Ouverture de droits"
		},
		{
			"type": "rectangle",
			"version": 1013,
			"versionNonce": 1466718458,
			"isDeleted": false,
			"id": "WCMyvQ1bJyak7d6_2JVm-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -206.73809523809507,
			"y": -85.98917748917734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 35,
			"seed": 55890389,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "8OTZt1nA"
				},
				{
					"id": "xhjGwgM0meYnczQnWTqTN",
					"type": "arrow"
				}
			],
			"updated": 1678980951785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 939,
			"versionNonce": 1725778854,
			"isDeleted": false,
			"id": "8OTZt1nA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -173.99809737432554,
			"y": -80.48917748917734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 108.52000427246094,
			"height": 24,
			"seed": 645505531,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980951785,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Orientation",
			"rawText": "Orientation",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "WCMyvQ1bJyak7d6_2JVm-",
			"originalText": "Orientation"
		},
		{
			"type": "rectangle",
			"version": 728,
			"versionNonce": 974181414,
			"isDeleted": false,
			"id": "hqTn7LaTJ7T-zlDGw7yux",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 184.47619047619065,
			"y": -4.761904761904873,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 1970034075,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "jIhFIvug"
				},
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "4fO_N5MmZS09UAYqEKuA-",
					"type": "arrow"
				},
				{
					"id": "RicfoWaBRJbtriBVjp76c",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"id": "vJRuzIxN1TalXOv6orNiR",
					"type": "arrow"
				}
			],
			"updated": 1678981646050,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 617,
			"versionNonce": 1146093114,
			"isDeleted": false,
			"id": "jIhFIvug",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 194.3061846778508,
			"y": 4.738095238095127,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 154.3400115966797,
			"height": 48,
			"seed": 643933589,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921170,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Activation Yaso\nCasting",
			"rawText": "Activation Yaso Casting",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "hqTn7LaTJ7T-zlDGw7yux",
			"originalText": "Activation Yaso Casting"
		},
		{
			"type": "rectangle",
			"version": 1009,
			"versionNonce": 1711602426,
			"isDeleted": false,
			"id": "EoY9T2Tw_jR-p9BwqysUh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -711.2164502164502,
			"y": 319.2813852813854,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 1888800955,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "lbgy1kUM"
				},
				{
					"id": "4fO_N5MmZS09UAYqEKuA-",
					"type": "arrow"
				},
				{
					"id": "g7X7bj1MM0cG4QezVgJnW",
					"type": "arrow"
				}
			],
			"updated": 1678981193613,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 917,
			"versionNonce": 622315942,
			"isDeleted": false,
			"id": "lbgy1kUM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -680.516453268208,
			"y": 340.7813852813854,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 112.60000610351562,
			"height": 24,
			"seed": 745139317,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678981193613,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Prescription",
			"rawText": "Prescription",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "EoY9T2Tw_jR-p9BwqysUh",
			"originalText": "Prescription"
		},
		{
			"type": "rectangle",
			"version": 1767,
			"versionNonce": 185995578,
			"isDeleted": false,
			"id": "iRh1_lu43TI20eWpk2IeJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 652.5714285714287,
			"y": -294.4761904761904,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 2117219323,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "4fO_N5MmZS09UAYqEKuA-",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "8So0Ayyz"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				}
			],
			"updated": 1678982129589,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1714,
			"versionNonce": 1710896998,
			"isDeleted": false,
			"id": "8So0Ayyz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 666.5514319283623,
			"y": -284.9761904761904,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 146.0399932861328,
			"height": 48,
			"seed": 1547132213,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678982129589,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Génération \nd'une fiche-info",
			"rawText": "Génération d'une fiche-info",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "iRh1_lu43TI20eWpk2IeJ",
			"originalText": "Génération d'une fiche-info"
		},
		{
			"type": "rectangle",
			"version": 988,
			"versionNonce": 1291706342,
			"isDeleted": false,
			"id": "aLZfsUiZAto4QSYf0IM5N",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 408.38095238095286,
			"y": -293.52380952380923,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 931195637,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "2oJnxCKw"
				},
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				}
			],
			"updated": 1678982126504,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 919,
			"versionNonce": 1916598650,
			"isDeleted": false,
			"id": "2oJnxCKw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 443.31095268612864,
			"y": -284.02380952380923,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104.13999938964844,
			"height": 48,
			"seed": 764357339,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678982126504,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Validation \nCasting",
			"rawText": "Validation Casting",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "aLZfsUiZAto4QSYf0IM5N",
			"originalText": "Validation Casting"
		},
		{
			"type": "rectangle",
			"version": 987,
			"versionNonce": 2124336378,
			"isDeleted": false,
			"id": "xrUNCIDj-kakB_4x-0pGn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 651.9047619047619,
			"y": -120.47619047619054,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 2139941845,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "bzzG9Lrg"
				},
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				}
			],
			"updated": 1678982133091,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 922,
			"versionNonce": 1497110438,
			"isDeleted": false,
			"id": "bzzG9Lrg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 709.6747623625256,
			"y": -98.97619047619054,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 58.459999084472656,
			"height": 24,
			"seed": 1021847547,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678982133091,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sortie",
			"rawText": "Sortie",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "xrUNCIDj-kakB_4x-0pGn",
			"originalText": "Sortie"
		},
		{
			"type": "diamond",
			"version": 553,
			"versionNonce": 1082537830,
			"isDeleted": false,
			"id": "-uPEBVDClufWpCgDOPYUs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -737.4242424242425,
			"y": -216.66666666666663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 193,
			"height": 174,
			"seed": 2057449947,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6Epq17Qk"
				},
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "BFAM6_AIx2OJEsUH5EkDe",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				}
			],
			"updated": 1678980921170,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 430,
			"versionNonce": 463985146,
			"isDeleted": false,
			"id": "6Epq17Qk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -683.284243034594,
			"y": -165.66666666666663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 85.22000122070312,
			"height": 72,
			"seed": 1420604501,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921170,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Interven\ntion \nsociale ?",
			"rawText": "Intervention sociale ?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "-uPEBVDClufWpCgDOPYUs",
			"originalText": "Intervention sociale ?"
		},
		{
			"type": "diamond",
			"version": 794,
			"versionNonce": 920017574,
			"isDeleted": false,
			"id": "1nbbvTP019Y3zMtBsLQJu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -336.46969696969734,
			"y": -283.40476190476164,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 193,
			"height": 174,
			"seed": 499036181,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "BFAM6_AIx2OJEsUH5EkDe",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "adxiSTuz"
				},
				{
					"id": "h96XBQ4UWkleAq78MN9i_",
					"type": "arrow"
				},
				{
					"id": "vJRuzIxN1TalXOv6orNiR",
					"type": "arrow"
				}
			],
			"updated": 1678980921170,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 680,
			"versionNonce": 206473914,
			"isDeleted": false,
			"id": "adxiSTuz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -281.1396989533399,
			"y": -220.40476190476164,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.84000396728516,
			"height": 48,
			"seed": 651413435,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921170,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "AS dispo\n?",
			"rawText": "AS dispo ?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "1nbbvTP019Y3zMtBsLQJu",
			"originalText": "AS dispo ?"
		},
		{
			"type": "arrow",
			"version": 1799,
			"versionNonce": 499260518,
			"isDeleted": false,
			"id": "ZsvmKZlMqpaCf_NLq5u7a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 321.0716701906952,
			"y": -13.761904761904873,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 146.3590427167697,
			"height": 203.76190476190436,
			"seed": 1727232635,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206552,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 9,
				"focus": 0.17169373549883996
			},
			"endBinding": {
				"elementId": "aLZfsUiZAto4QSYf0IM5N",
				"gap": 9,
				"focus": -0.023201856148491885
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					146.3590427167697,
					-203.76190476190436
				]
			]
		},
		{
			"type": "arrow",
			"version": 2454,
			"versionNonce": 760061862,
			"isDeleted": false,
			"id": "-QwkH20PZPcRlsZv_ixcn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 591.1727471145855,
			"y": -253.6502830739114,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 47.48778140823731,
			"height": 0.6740011720519874,
			"seed": 814442523,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206552,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "aLZfsUiZAto4QSYf0IM5N",
				"gap": 8.791794733632628,
				"focus": 0.14797659031343838
			},
			"endBinding": {
				"elementId": "iRh1_lu43TI20eWpk2IeJ",
				"gap": 13.91090004860581,
				"focus": -0.27154758232270915
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					47.48778140823731,
					0.6740011720519874
				]
			]
		},
		{
			"type": "arrow",
			"version": 2562,
			"versionNonce": 520534758,
			"isDeleted": false,
			"id": "dk97D9FPiFR2MGG87rTzm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 743.393662016895,
			"y": -214.76190476190465,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.182745216185708,
			"height": 81.95238095238082,
			"seed": 1802836123,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206552,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "iRh1_lu43TI20eWpk2IeJ",
				"gap": 12.71428571428578,
				"focus": -0.06361234480056409
			},
			"endBinding": {
				"elementId": "xrUNCIDj-kakB_4x-0pGn",
				"gap": 12.333333333333258,
				"focus": -0.005366327770120938
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-3.182745216185708,
					81.95238095238082
				]
			]
		},
		{
			"type": "arrow",
			"version": 2045,
			"versionNonce": 159018534,
			"isDeleted": false,
			"id": "9anXUgdGyjpTmP18qhR9R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -649.142076944438,
			"y": -394.1515151515152,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2.72591514523765,
			"height": 181.08970984256334,
			"seed": 1966656571,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206552,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "NzHyNbfrBXRmrgGjoAHQ-",
				"gap": 1,
				"focus": 0.008175923315477868
			},
			"endBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 1,
				"focus": -0.04390243902439024
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					2.72591514523765,
					181.08970984256334
				]
			]
		},
		{
			"type": "arrow",
			"version": 2683,
			"versionNonce": 940635366,
			"isDeleted": false,
			"id": "ni2QzpTojnGKNLLscAgJy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -636.7946920874946,
			"y": -33.492377984491384,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.3587517278774612,
			"height": 350.44042993254334,
			"seed": 223079477,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "s9jme9sd"
				}
			],
			"updated": 1678982253486,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 10.06085278729509,
				"focus": -0.03324124457531012
			},
			"endBinding": {
				"elementId": "EoY9T2Tw_jR-p9BwqysUh",
				"gap": 2.333333333333428,
				"focus": -0.10164842755474358
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					3.3587517278774612,
					350.44042993254334
				]
			]
		},
		{
			"type": "text",
			"version": 12,
			"versionNonce": 259394810,
			"isDeleted": false,
			"id": "s9jme9sd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -340.31846197323387,
			"y": -132.1756593101893,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.880000114440918,
			"height": 24,
			"seed": 1256266107,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921171,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "N",
			"rawText": "N",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ni2QzpTojnGKNLLscAgJy",
			"originalText": "N"
		},
		{
			"type": "arrow",
			"version": 1709,
			"versionNonce": 379952294,
			"isDeleted": false,
			"id": "BFAM6_AIx2OJEsUH5EkDe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -431.9970470479683,
			"y": -393.6363636363637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 168.326249360088,
			"height": 192.03121479123485,
			"seed": 316656213,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206552,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "B_bFo4BTtkcueEW9N0oAP",
				"gap": 1,
				"focus": -0.0678969722069914
			},
			"endBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 16,
				"focus": -0.23271723377478049
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-168.326249360088,
					192.03121479123485
				]
			]
		},
		{
			"type": "arrow",
			"version": 2549,
			"versionNonce": 312639718,
			"isDeleted": false,
			"id": "RMyOfBscTSC30ql2aQEdX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 77.06375677294372,
			"y": -398.6666666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187.57985284128333,
			"height": 380.2889143052402,
			"seed": 261857685,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206550,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ZYXreMGpuENjDcit2qZdV",
				"gap": 1,
				"focus": 0.21454075131711942
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 13.6158475995216,
				"focus": 0.15849067526329877
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					187.57985284128333,
					380.2889143052402
				]
			]
		},
		{
			"type": "arrow",
			"version": 3137,
			"versionNonce": 817310502,
			"isDeleted": false,
			"id": "wxJ07Lq37C28Dl9wVhOiz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -538.1563740062902,
			"y": -143.86310858970648,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 197.6989849305861,
			"height": 37.354647533736625,
			"seed": 968780885,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6uMnIGkW"
				}
			],
			"updated": 1678982206553,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 14.740958021623143,
				"focus": 0.06001433988940333
			},
			"endBinding": {
				"elementId": "1nbbvTP019Y3zMtBsLQJu",
				"gap": 13.949858074507574,
				"focus": 0.04367644870664801
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					197.6989849305861,
					-37.354647533736625
				]
			]
		},
		{
			"type": "text",
			"version": 11,
			"versionNonce": 612275834,
			"isDeleted": false,
			"id": "6uMnIGkW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -498.1612452647703,
			"y": 22.23064086946293,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.319999694824219,
			"height": 24,
			"seed": 1148685621,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921171,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Y",
			"rawText": "Y",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "wxJ07Lq37C28Dl9wVhOiz",
			"originalText": "Y"
		},
		{
			"type": "arrow",
			"version": 2071,
			"versionNonce": 1162982522,
			"isDeleted": false,
			"id": "4fO_N5MmZS09UAYqEKuA-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -527.1861471861472,
			"y": 339.09790424786945,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 755.6017316017319,
			"height": 263.19273925305407,
			"seed": 606533205,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982253486,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "EoY9T2Tw_jR-p9BwqysUh",
				"gap": 10.030303030303003,
				"focus": -0.39337167253218913
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 13.667069756720252,
				"focus": 0.028992253313350747
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					535.6991341991343,
					-2.063272213237383
				],
				[
					755.6017316017319,
					-263.19273925305407
				]
			]
		},
		{
			"type": "ellipse",
			"version": 487,
			"versionNonce": 1809319206,
			"isDeleted": false,
			"id": "6HtuCLJMvT_QVHwWsV4oJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -272.91666666666663,
			"y": 146.5530303030302,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.619047619047592,
			"height": 25.714285714285666,
			"seed": 695418011,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "Q3dWcUrpYCeifMjJPRcFs",
					"type": "arrow"
				},
				{
					"id": "xhjGwgM0meYnczQnWTqTN",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"id": "h96XBQ4UWkleAq78MN9i_",
					"type": "arrow"
				},
				{
					"id": "RicfoWaBRJbtriBVjp76c",
					"type": "arrow"
				},
				{
					"id": "g7X7bj1MM0cG4QezVgJnW",
					"type": "arrow"
				},
				{
					"id": "oK-Zk-4GXqz1CZZOUgUk0",
					"type": "arrow"
				},
				{
					"id": "b9UoAtbwmNe5QRxebIemA",
					"type": "arrow"
				}
			],
			"updated": 1678980938957,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 3476,
			"versionNonce": 918166714,
			"isDeleted": false,
			"id": "Q3dWcUrpYCeifMjJPRcFs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -247.1096500556693,
			"y": 145.60778512269377,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 154.11327718209026,
			"height": 109.91964071365126,
			"seed": 1485197243,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206550,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 5.038865544230551,
				"focus": -0.32385913708852365
			},
			"endBinding": {
				"elementId": "svKVjGGJ-L36LKHMoRXSC",
				"gap": 1.4628230900294255,
				"focus": 0.5873526492083172
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					154.11327718209026,
					-109.91964071365126
				]
			]
		},
		{
			"type": "arrow",
			"version": 2747,
			"versionNonce": 2039117178,
			"isDeleted": false,
			"id": "xhjGwgM0meYnczQnWTqTN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -252.11470225956666,
			"y": 145.63158972040628,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 111.49340736617825,
			"height": 191.02348739906813,
			"seed": 192370805,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206550,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 2.4127994635446033,
				"focus": -0.06678306110842487
			},
			"endBinding": {
				"elementId": "WCMyvQ1bJyak7d6_2JVm-",
				"gap": 5.597279810515488,
				"focus": 0.0761428994787459
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					111.49340736617825,
					-191.02348739906813
				]
			]
		},
		{
			"type": "arrow",
			"version": 1705,
			"versionNonce": 959277094,
			"isDeleted": false,
			"id": "g7X7bj1MM0cG4QezVgJnW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -575.7850041538568,
			"y": 308.1688311688316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 307.6172866395904,
			"height": 136.12839089096104,
			"seed": 408160411,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982253487,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "EoY9T2Tw_jR-p9BwqysUh",
				"gap": 11.112554112553767,
				"focus": -0.46176150885938627
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"focus": -0.45350070957135247,
				"gap": 2.381339098730564
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					187.8001556690083,
					-61.770562770563174
				],
				[
					307.6172866395904,
					-136.12839089096104
				]
			]
		},
		{
			"type": "arrow",
			"version": 1527,
			"versionNonce": 607311462,
			"isDeleted": false,
			"id": "h96XBQ4UWkleAq78MN9i_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -258.282436313049,
			"y": -104.80775175091588,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.4608253863556797,
			"height": 237.13136039413217,
			"seed": 764902139,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "bmPIrZgO"
				}
			],
			"updated": 1678982206553,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1nbbvTP019Y3zMtBsLQJu",
				"gap": 15.676543357032173,
				"focus": 0.17591629265390202
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 14.348903889437539,
				"focus": -0.21949744804323437
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-3.4608253863556797,
					237.13136039413217
				]
			]
		},
		{
			"type": "text",
			"version": 11,
			"versionNonce": 304255846,
			"isDeleted": false,
			"id": "bmPIrZgO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -314.09153816155924,
			"y": 156.0205299627154,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.319999694824219,
			"height": 24,
			"seed": 384356219,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980929723,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Y",
			"rawText": "Y",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "h96XBQ4UWkleAq78MN9i_",
			"originalText": "Y"
		},
		{
			"type": "arrow",
			"version": 1656,
			"versionNonce": 1503074726,
			"isDeleted": false,
			"id": "vJRuzIxN1TalXOv6orNiR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -128.83687861773234,
			"y": -188.2534965380596,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 359.7598338750395,
			"height": 171.29198460468473,
			"seed": 130643573,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "Cz8VwmLx"
				}
			],
			"updated": 1678982206553,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1nbbvTP019Y3zMtBsLQJu",
				"gap": 16.75,
				"focus": -0.514508732902157
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 12.199607171470007,
				"focus": 0.35224134294014486
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					359.7598338750395,
					171.29198460468473
				]
			]
		},
		{
			"type": "text",
			"version": 8,
			"versionNonce": 2081973030,
			"isDeleted": false,
			"id": "Cz8VwmLx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -143.38317563418536,
			"y": 297.9777759238248,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.880000114440918,
			"height": 24,
			"seed": 14916411,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678980921171,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "N",
			"rawText": "N",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "vJRuzIxN1TalXOv6orNiR",
			"originalText": "N"
		},
		{
			"type": "arrow",
			"version": 566,
			"versionNonce": 711599526,
			"isDeleted": false,
			"id": "RicfoWaBRJbtriBVjp76c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.309456686235,
			"y": 152.7180352171343,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 416.8445882213666,
			"height": 107.33742902124501,
			"seed": 833241979,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206550,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 2.6051961462544266,
				"focus": -0.21602502504898596
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 11.941058941058998,
				"focus": 0.1580394615813451
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					416.8445882213666,
					-107.33742902124501
				]
			]
		},
		{
			"type": "arrow",
			"version": 1857,
			"versionNonce": 10333178,
			"isDeleted": false,
			"id": "oK-Zk-4GXqz1CZZOUgUk0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -432.47708413144267,
			"y": 38.73593073593099,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 153.70390917404075,
			"height": 109.4723967241473,
			"seed": 439549306,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206550,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "gxL-DKMyjIMlXMJhDjepf",
				"gap": 8.175324675324816,
				"focus": 0.1295957563563251
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 9.067807937873162,
				"focus": -0.17327116342937463
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					153.70390917404075,
					109.4723967241473
				]
			]
		},
		{
			"type": "arrow",
			"version": 1307,
			"versionNonce": 429007674,
			"isDeleted": false,
			"id": "b9UoAtbwmNe5QRxebIemA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -402.2294372294372,
			"y": 135.7755785347214,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 127.05241252050877,
			"height": 22.151254977682413,
			"seed": 1881295206,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678982206549,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "h-dptHX8SFnNUiBMEdZjL",
				"gap": 8.285714285713823,
				"focus": -0.46765336801185725
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 2.337484188077525,
				"focus": -0.10079040235677265
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					127.05241252050877,
					22.151254977682413
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 808.7597402597402,
		"scrollY": 794.0259740259739,
		"zoom": {
			"value": 0.6000000000000001
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%