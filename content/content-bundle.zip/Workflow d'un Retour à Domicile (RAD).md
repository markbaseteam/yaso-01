#Draft 

| Étape                           | Interop | Service | AS  |  Intervenants |
| ------------------------------- | ------- | ------- | --- |  ------------ |
| Identité du patient                        | ⚫️      | ⚫️     | ⚫️   |               | 
| Condition médicale du patient              | ⚫️      | ⚫️     |      |                   |
| Prescription                    |         | ⚫️     |      |                         |
| Publication aux intervenants                     |         | ⚫️     | ⚫️   |             |
| Positionnement des intervenants |         |         |     |        ⚫️          |
| Sélection des intervenants                       |         | ⚫️     | ⚫️   |              |
| Présentation au patient         |         | ⚫️     | ⚫️   |               |
| Intervention sociale si besoin  | ⚫️     |         | ⚫️   |                   |
| Engagement des intervenants     |         | ⚫️     | ⚫️   |               |
| Confirmation RAD et sortie      |         | ⚫️     |      |               |

