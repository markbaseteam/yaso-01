---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
｡◕‿◕｡ ^RFlznL3S

｡◕‿◕｡ ^bBMNajye

€ ^dAC2TKxw

ಠ_ಠ ^fYfFhuk6

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.19",
	"elements": [
		{
			"type": "ellipse",
			"version": 3541,
			"versionNonce": 441360729,
			"isDeleted": false,
			"id": "5UaVyvxK1ZOh-zEe7DlAz",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.539098529970085,
			"x": -950.6695139183443,
			"y": -978.9669666214384,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.0086888285436,
			"height": 39.58539212433324,
			"seed": 1880479783,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973338,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3244,
			"versionNonce": 1885961399,
			"isDeleted": false,
			"id": "9ewIPWIh-c5_Gd3FUmJUZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -930.7373070628815,
			"y": -937.8120615474224,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.1103617329484976,
			"height": 47.99059238514134,
			"seed": 653287881,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973338,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.1103617329484976,
					47.99059238514134
				]
			]
		},
		{
			"type": "line",
			"version": 3197,
			"versionNonce": 1115885113,
			"isDeleted": false,
			"id": "KhY9XN4T8PbKpD26gtcWA",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -932.554313381228,
			"y": -888.5254435617212,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.997283004423654,
			"height": 29.267173117054593,
			"seed": 1209416519,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.997283004423654,
					29.267173117054593
				]
			]
		},
		{
			"type": "line",
			"version": 3211,
			"versionNonce": 1705430487,
			"isDeleted": false,
			"id": "rNh36VvS64gCCuysDoZoK",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -933.2373914875973,
			"y": -890.9161374002792,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.447961400752256,
			"height": 27.007242561909063,
			"seed": 401817769,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-18.447961400752256,
					27.007242561909063
				]
			]
		},
		{
			"type": "line",
			"version": 3979,
			"versionNonce": 1196875545,
			"isDeleted": false,
			"id": "HNqn4_gnnpigR9M9HvTen",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -950.0283258832316,
			"y": -909.2024280015044,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.2234428852339,
			"height": 13.138340642870633,
			"seed": 73218663,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.2234428852339,
					-13.138340642870633
				]
			]
		},
		{
			"type": "line",
			"version": 3540,
			"versionNonce": 626850551,
			"isDeleted": false,
			"id": "XmefmYvMNHY5mwTBxhtbg",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -930.9870479024456,
			"y": -922.064547987829,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.75590103094578,
			"height": 12.69257141944536,
			"seed": 1727480713,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.75590103094578,
					12.69257141944536
				]
			]
		},
		{
			"type": "line",
			"version": 5075,
			"versionNonce": 658347001,
			"isDeleted": false,
			"id": "UJSQhVOSUfeiiciJP89Z_",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -917.208448450597,
			"y": -974.9166887296792,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 35.469487067948236,
			"height": 26.797119024154554,
			"seed": 431445383,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.428511041695344,
					11.54239259015419
				],
				[
					-18.99942829090763,
					16.922870510125026
				],
				[
					-29.92991122004222,
					17.405355430747225
				],
				[
					-35.469487067948236,
					26.797119024154554
				]
			]
		},
		{
			"type": "line",
			"version": 4251,
			"versionNonce": 605062167,
			"isDeleted": false,
			"id": "2-99ZFIq0cIBaISKhD-MW",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -919.4896376271868,
			"y": -975.3938786046206,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 31.391797857791666,
			"height": 16.951567529518332,
			"seed": 3664489,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.69688607651749,
					10.352204813966067
				],
				[
					-22.217761516390087,
					15.523169796022
				],
				[
					-31.391797857791666,
					16.951567529518332
				]
			]
		},
		{
			"type": "line",
			"version": 4285,
			"versionNonce": 1178250457,
			"isDeleted": false,
			"id": "V11OspkyQcSe1GFfmbox-",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -921.2552572206102,
			"y": -977.5187444549181,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.810402227566794,
			"height": 13.783469190753605,
			"seed": 794889383,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.990035694617003,
					5.596110597600333
				],
				[
					-27.810402227566794,
					13.783469190753605
				]
			]
		},
		{
			"type": "line",
			"version": 4205,
			"versionNonce": 1370876215,
			"isDeleted": false,
			"id": "piYMXHpl8b83Wnfwt2IOs",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -919.7358817663849,
			"y": -975.8087971887176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 29.400531201339827,
			"height": 14.953150903025403,
			"seed": 1015067977,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-11.169685826434666,
					7.774076142824189
				],
				[
					-22.72004691177876,
					12.568444676529314
				],
				[
					-29.400531201339827,
					14.953150903025403
				]
			]
		},
		{
			"type": "line",
			"version": 4237,
			"versionNonce": 1004644793,
			"isDeleted": false,
			"id": "3K8MD_ZPtiPQU54xQWquL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -921.1809807108723,
			"y": -976.5110928627471,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28.370815260281734,
			"height": 13.524021667853914,
			"seed": 1359404999,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-13.331408416513465,
					7.206429447227113
				],
				[
					-28.370815260281734,
					13.524021667853914
				]
			]
		},
		{
			"type": "line",
			"version": 4276,
			"versionNonce": 733063767,
			"isDeleted": false,
			"id": "G3OWO7y6vVHXb9McfDi2r",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -923.9704890598932,
			"y": -977.9976846842981,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24.03343055334538,
			"height": 11.630434462121464,
			"seed": 1328358441,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.193707781287326,
					4.360953272996919
				],
				[
					-24.03343055334538,
					11.630434462121464
				]
			]
		},
		{
			"type": "line",
			"version": 2799,
			"versionNonce": 1633028761,
			"isDeleted": false,
			"id": "FgrLgFFIzr1m-fPjT4Uhi",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -950.4939601324642,
			"y": -958.3201694940999,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 11.515026751223143,
			"height": 10.315619276825327,
			"seed": 1623543527,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.475191618488947,
					-0.6551160050175875
				],
				[
					-10.03408920645624,
					-5.019278968865968
				],
				[
					-8.208165607205311,
					-10.124357578225386
				],
				[
					-1.550649752667816,
					-10.315619276825327
				],
				[
					1.4809375447669013,
					-4.738642644752032
				]
			]
		},
		{
			"type": "line",
			"version": 1778,
			"versionNonce": 249055095,
			"isDeleted": false,
			"id": "D7jXnzfNiHcnp3Mb-iJhl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -961.8284210305762,
			"y": -965.7551191027087,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.945710386699,
			"height": 5.740532196763912,
			"seed": 1948825353,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					4.907560686973476,
					4.138938907553117
				],
				[
					10.945710386699,
					5.740532196763912
				]
			]
		},
		{
			"type": "line",
			"version": 1975,
			"versionNonce": 525029241,
			"isDeleted": false,
			"id": "kC_p-URY81kD5H_ccLNoL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -960.6363514152533,
			"y": -967.0185830481928,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.790888165556577,
			"height": 5.257909218988336,
			"seed": 1227414023,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					6.034574714704959,
					0.7319781829596209
				],
				[
					8.790888165556577,
					5.257909218988336
				]
			]
		},
		{
			"type": "line",
			"version": 2078,
			"versionNonce": 1231962263,
			"isDeleted": false,
			"id": "sJuIfwjPLO430JumjaiiP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -960.4946242820071,
			"y": -965.5734313756775,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.790888165556577,
			"height": 5.257909218988336,
			"seed": 1575939561,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.9432084776774765,
					2.5123207231984037
				],
				[
					8.790888165556577,
					5.257909218988336
				]
			]
		},
		{
			"type": "line",
			"version": 1572,
			"versionNonce": 2080700505,
			"isDeleted": false,
			"id": "C9WcGQAmU8CW3UVqk9L6q",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -908.6536979611664,
			"y": -857.6437561392813,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.82339966210755,
			"height": 57.906813536575534,
			"seed": 1865285927,
			"groupIds": [
				"0D8_giw6jRLaN715lax9C"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0611428712387145,
					-45.24377678602001
				],
				[
					-1.8822239125909896,
					-57.906813536575534
				],
				[
					-7.3514586456642546,
					-56.283486729600796
				],
				[
					-8.762256790868834,
					-42.160271594881515
				]
			]
		},
		{
			"type": "line",
			"version": 1652,
			"versionNonce": 1831343543,
			"isDeleted": false,
			"id": "_pksF1NWlATETz1mUYXWZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -460.47187977934794,
			"y": -856.7346652301903,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.82339966210755,
			"height": 57.906813536575534,
			"seed": 401100279,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973339,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0611428712387145,
					-45.24377678602001
				],
				[
					-1.8822239125909896,
					-57.906813536575534
				],
				[
					-7.3514586456642546,
					-56.283486729600796
				],
				[
					-8.762256790868834,
					-42.160271594881515
				]
			]
		},
		{
			"type": "ellipse",
			"version": 4394,
			"versionNonce": 1639194807,
			"isDeleted": false,
			"id": "-Jdv_paN5GAI3IVAj2r8G",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.539098529970085,
			"x": -842.6998169486476,
			"y": 39.16434650987482,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.0086888285436,
			"height": 39.58539212433324,
			"seed": 1157755767,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 4053,
			"versionNonce": 1537518137,
			"isDeleted": false,
			"id": "a1ze5DgHXITc1TdJcIQgF",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -822.7676100931849,
			"y": 80.31925158389068,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.1103617329484976,
			"height": 47.99059238514134,
			"seed": 2061656953,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.1103617329484976,
					47.99059238514134
				]
			]
		},
		{
			"type": "line",
			"version": 4004,
			"versionNonce": 503116247,
			"isDeleted": false,
			"id": "rjYy_Hjma2yMp25FOZCug",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -824.5846164115313,
			"y": 129.60586956959213,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.997283004423654,
			"height": 29.267173117054593,
			"seed": 1703046295,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.997283004423654,
					29.267173117054593
				]
			]
		},
		{
			"type": "line",
			"version": 4020,
			"versionNonce": 31783705,
			"isDeleted": false,
			"id": "Z4nno5-iTBPlVB7cRjlZV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -825.2676945179006,
			"y": 127.21517573103411,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.447961400752256,
			"height": 27.007242561909063,
			"seed": 2073660505,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-18.447961400752256,
					27.007242561909063
				]
			]
		},
		{
			"type": "line",
			"version": 4788,
			"versionNonce": 927899383,
			"isDeleted": false,
			"id": "XhcOyqCjFAIx9plACr72N",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -842.0586289135349,
			"y": 108.92888512980899,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.2234428852339,
			"height": 13.138340642870633,
			"seed": 1305919927,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.2234428852339,
					-13.138340642870633
				]
			]
		},
		{
			"type": "line",
			"version": 4349,
			"versionNonce": 564670457,
			"isDeleted": false,
			"id": "NVsiT9NHiuU9KA3mEqP2e",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -823.017350932749,
			"y": 96.06676514348415,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.75590103094578,
			"height": 12.69257141944536,
			"seed": 825792825,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.75590103094578,
					12.69257141944536
				]
			]
		},
		{
			"type": "line",
			"version": 5928,
			"versionNonce": 1345169431,
			"isDeleted": false,
			"id": "ZWzBNMVHItza_easHKcWh",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -809.2387514809003,
			"y": 43.21462440163391,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 35.469487067948236,
			"height": 26.797119024154554,
			"seed": 253981399,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.428511041695344,
					11.54239259015419
				],
				[
					-18.99942829090763,
					16.922870510125026
				],
				[
					-29.92991122004222,
					17.405355430747225
				],
				[
					-35.469487067948236,
					26.797119024154554
				]
			]
		},
		{
			"type": "line",
			"version": 5104,
			"versionNonce": 1358022873,
			"isDeleted": false,
			"id": "P-tJQoXCEd4vX5lEgDGJv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -811.5199406574901,
			"y": 42.73743452669278,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 31.391797857791666,
			"height": 16.951567529518332,
			"seed": 2099448345,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.69688607651749,
					10.352204813966067
				],
				[
					-22.217761516390087,
					15.523169796022
				],
				[
					-31.391797857791666,
					16.951567529518332
				]
			]
		},
		{
			"type": "line",
			"version": 5138,
			"versionNonce": 1183747383,
			"isDeleted": false,
			"id": "JQE5RdozOxYEajmVUb5rg",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -813.2855602509136,
			"y": 40.6125686763951,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.810402227566794,
			"height": 13.783469190753605,
			"seed": 570228727,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.990035694617003,
					5.596110597600333
				],
				[
					-27.810402227566794,
					13.783469190753605
				]
			]
		},
		{
			"type": "line",
			"version": 5058,
			"versionNonce": 425018809,
			"isDeleted": false,
			"id": "vROIxdUjm5NOyvDhAXsk-",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -811.7661847966882,
			"y": 42.322515942595786,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 29.400531201339827,
			"height": 14.953150903025403,
			"seed": 1212964601,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-11.169685826434666,
					7.774076142824189
				],
				[
					-22.72004691177876,
					12.568444676529314
				],
				[
					-29.400531201339827,
					14.953150903025403
				]
			]
		},
		{
			"type": "line",
			"version": 5090,
			"versionNonce": 1171639895,
			"isDeleted": false,
			"id": "RVHMXXeFeW3qav2uAjmKx",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -813.2112837411756,
			"y": 41.62022026856603,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28.370815260281734,
			"height": 13.524021667853914,
			"seed": 2020075799,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-13.331408416513465,
					7.206429447227113
				],
				[
					-28.370815260281734,
					13.524021667853914
				]
			]
		},
		{
			"type": "line",
			"version": 5129,
			"versionNonce": 100017817,
			"isDeleted": false,
			"id": "i2SnQfsnCuU0ScpMchRM3",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -816.0007920901966,
			"y": 40.13362844701534,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24.03343055334538,
			"height": 11.630434462121464,
			"seed": 288888793,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.193707781287326,
					4.360953272996919
				],
				[
					-24.03343055334538,
					11.630434462121464
				]
			]
		},
		{
			"type": "line",
			"version": 3608,
			"versionNonce": 416803703,
			"isDeleted": false,
			"id": "ZSqF--L7s8NW1bR2yIwwD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -842.5242631627675,
			"y": 59.81114363721322,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 11.515026751223143,
			"height": 10.315619276825327,
			"seed": 1339600439,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.475191618488947,
					-0.6551160050175875
				],
				[
					-10.03408920645624,
					-5.019278968865968
				],
				[
					-8.208165607205311,
					-10.124357578225386
				],
				[
					-1.550649752667816,
					-10.315619276825327
				],
				[
					1.4809375447669013,
					-4.738642644752032
				]
			]
		},
		{
			"type": "line",
			"version": 2631,
			"versionNonce": 1904733049,
			"isDeleted": false,
			"id": "6oqOI7u0qlz5jXl_4YtTU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -853.8587240608796,
			"y": 52.37619402860442,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.945710386699,
			"height": 5.740532196763912,
			"seed": 972666041,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					4.907560686973476,
					4.138938907553117
				],
				[
					10.945710386699,
					5.740532196763912
				]
			]
		},
		{
			"type": "line",
			"version": 2828,
			"versionNonce": 1004102807,
			"isDeleted": false,
			"id": "7GIh4GcyFKwiHY6W39sMi",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -852.6666544455567,
			"y": 51.11273008312055,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.790888165556577,
			"height": 5.257909218988336,
			"seed": 1127468887,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					6.034574714704959,
					0.7319781829596209
				],
				[
					8.790888165556577,
					5.257909218988336
				]
			]
		},
		{
			"type": "line",
			"version": 2931,
			"versionNonce": 340661337,
			"isDeleted": false,
			"id": "iUUJo3vp_FqHP8-MjHdTH",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 0,
			"x": -852.5249273123104,
			"y": 52.55788175563585,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.790888165556577,
			"height": 5.257909218988336,
			"seed": 372553113,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.9432084776774765,
					2.5123207231984037
				],
				[
					8.790888165556577,
					5.257909218988336
				]
			]
		},
		{
			"type": "line",
			"version": 2377,
			"versionNonce": 781105591,
			"isDeleted": false,
			"id": "a2Vs5nXUpaLXuz1BCJX9_",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -800.6840009914697,
			"y": 160.487556992032,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.82339966210755,
			"height": 57.906813536575534,
			"seed": 483249271,
			"groupIds": [
				"x9VoK2SnaRbIRC8CbsoCS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679056165328,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0611428712387145,
					-45.24377678602001
				],
				[
					-1.8822239125909896,
					-57.906813536575534
				],
				[
					-7.3514586456642546,
					-56.283486729600796
				],
				[
					-8.762256790868834,
					-42.160271594881515
				]
			]
		},
		{
			"type": "ellipse",
			"version": 3876,
			"versionNonce": 1994702807,
			"isDeleted": false,
			"id": "kSCKe88Z5dIapLSHVrWAs",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 8.480750034618307,
			"x": -611.5737029897379,
			"y": -953.6452298769486,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.0086888285436,
			"height": 39.58539212433324,
			"seed": 1761580873,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3578,
			"versionNonce": 1722354969,
			"isDeleted": false,
			"id": "GMBxxH5xLovVJgJHGSzHo",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -545.1967810498331,
			"y": -944.6602441033556,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.1103617329484976,
			"height": 47.99059238514134,
			"seed": 1507794375,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.1103617329484976,
					47.99059238514134
				]
			]
		},
		{
			"type": "line",
			"version": 3543,
			"versionNonce": 2114759927,
			"isDeleted": false,
			"id": "Rz3Ty5OYpO2iAnjQ7YGOW",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -514.9367237456746,
			"y": -933.8759656845207,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.997283004423654,
			"height": 29.267173117054593,
			"seed": 226477609,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.997283004423654,
					29.267173117054593
				]
			]
		},
		{
			"type": "line",
			"version": 3575,
			"versionNonce": 941228537,
			"isDeleted": false,
			"id": "ulo01ch3irQdwi85aZPRP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -503.63789117492945,
			"y": -915.5648938829931,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.447961400752256,
			"height": 27.007242561909063,
			"seed": 1608895719,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-18.447961400752256,
					27.007242561909063
				]
			]
		},
		{
			"type": "line",
			"version": 4313,
			"versionNonce": 1878652439,
			"isDeleted": false,
			"id": "oLbRCRCDY0EDe14gffYn-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -558.729846040377,
			"y": -906.2595790886248,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.2234428852339,
			"height": 13.138340642870633,
			"seed": 1406605577,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.2234428852339,
					-13.138340642870633
				]
			]
		},
		{
			"type": "line",
			"version": 3874,
			"versionNonce": 492395225,
			"isDeleted": false,
			"id": "zViAt0VJqxJX-Ou6d6wsn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -554.1926114568626,
			"y": -937.2311057328409,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.75590103094578,
			"height": 12.69257141944536,
			"seed": 1267308551,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.75590103094578,
					12.69257141944536
				]
			]
		},
		{
			"type": "line",
			"version": 5411,
			"versionNonce": 60889911,
			"isDeleted": false,
			"id": "LJcearFT0_ebwhekkA2YI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -575.8878433930273,
			"y": -942.1548755130768,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 35.469487067948236,
			"height": 26.797119024154554,
			"seed": 1031868393,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.428511041695344,
					11.54239259015419
				],
				[
					-18.99942829090763,
					16.922870510125026
				],
				[
					-29.92991122004222,
					17.405355430747225
				],
				[
					-35.469487067948236,
					26.797119024154554
				]
			]
		},
		{
			"type": "line",
			"version": 4589,
			"versionNonce": 1459263417,
			"isDeleted": false,
			"id": "HFZzG8kI8ALXrzu1MTpda",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -582.9724501958575,
			"y": -939.0737310000682,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 31.391797857791666,
			"height": 16.951567529518332,
			"seed": 583466791,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.69688607651749,
					10.352204813966067
				],
				[
					-22.217761516390087,
					15.523169796022
				],
				[
					-31.391797857791666,
					16.951567529518332
				]
			]
		},
		{
			"type": "line",
			"version": 4621,
			"versionNonce": 493263959,
			"isDeleted": false,
			"id": "Njzhp91YMcC8oDgl4kL5V",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -589.5490829482711,
			"y": -937.9187850824353,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.810402227566794,
			"height": 13.783469190753605,
			"seed": 277424841,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.990035694617003,
					5.596110597600333
				],
				[
					-27.810402227566794,
					13.783469190753605
				]
			]
		},
		{
			"type": "line",
			"version": 4542,
			"versionNonce": 1193359513,
			"isDeleted": false,
			"id": "V6AiZsZpz5-rBUOsG8NbB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -586.0224216171633,
			"y": -937.9827733949159,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 29.400531201339827,
			"height": 14.953150903025403,
			"seed": 2013954631,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-11.169685826434666,
					7.774076142824189
				],
				[
					-22.72004691177876,
					12.568444676529314
				],
				[
					-29.400531201339827,
					14.953150903025403
				]
			]
		},
		{
			"type": "line",
			"version": 4573,
			"versionNonce": 555678071,
			"isDeleted": false,
			"id": "REAqBXL0F5sXP6dxX9ajU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -588.0960771477268,
			"y": -936.9376606894017,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28.370815260281734,
			"height": 13.524021667853914,
			"seed": 1166731689,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-13.331408416513465,
					7.206429447227113
				],
				[
					-28.370815260281734,
					13.524021667853914
				]
			]
		},
		{
			"type": "line",
			"version": 4611,
			"versionNonce": 1065401721,
			"isDeleted": false,
			"id": "0IGF-rFE1EaU8tgn0gfoD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.94165150464822,
			"x": -592.2249753580462,
			"y": -936.3361528855241,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24.03343055334538,
			"height": 11.630434462121464,
			"seed": 1546690919,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.193707781287326,
					4.360953272996919
				],
				[
					-24.03343055334538,
					11.630434462121464
				]
			]
		},
		{
			"type": "line",
			"version": 3163,
			"versionNonce": 68072087,
			"isDeleted": false,
			"id": "bI3WB_aElmkbIVzUGCbSc",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 4.94165150464822,
			"x": -596.2930400414225,
			"y": -904.424409965739,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 11.515026751223143,
			"height": 10.315619276825327,
			"seed": 900844681,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973340,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.475191618488947,
					-0.6551160050175875
				],
				[
					-10.03408920645624,
					-5.019278968865968
				],
				[
					-8.208165607205311,
					-10.124357578225386
				],
				[
					-1.550649752667816,
					-10.315619276825327
				],
				[
					1.4809375447669013,
					-4.738642644752032
				]
			]
		},
		{
			"type": "line",
			"version": 2142,
			"versionNonce": 257730137,
			"isDeleted": false,
			"id": "cUTxp7PY5UGpWwx4jo-BK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 4.94165150464822,
			"x": -605.5272006438788,
			"y": -911.4327644438316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.945710386699,
			"height": 5.740532196763912,
			"seed": 277208199,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					4.907560686973476,
					4.138938907553117
				],
				[
					10.945710386699,
					5.740532196763912
				]
			]
		},
		{
			"type": "line",
			"version": 2339,
			"versionNonce": 518670263,
			"isDeleted": false,
			"id": "dzuRVnR9HaruiSMDmWS8Q",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 4.94165150464822,
			"x": -605.3468392530445,
			"y": -910.434240103303,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.790888165556577,
			"height": 5.257909218988336,
			"seed": 146363241,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					6.034574714704959,
					0.7319781829596209
				],
				[
					8.790888165556577,
					5.257909218988336
				]
			]
		},
		{
			"type": "line",
			"version": 2442,
			"versionNonce": 1367896889,
			"isDeleted": false,
			"id": "SiUqjW5uPb61nVWlRVqq6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 4.94165150464822,
			"x": -605.0887292507667,
			"y": -911.1595565708823,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.790888165556577,
			"height": 5.257909218988336,
			"seed": 2026288039,
			"groupIds": [
				"F00n8lwU1IawkPDAaPMN8",
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.9432084776774765,
					2.5123207231984037
				],
				[
					8.790888165556577,
					5.257909218988336
				]
			]
		},
		{
			"type": "rectangle",
			"version": 390,
			"versionNonce": 1071003863,
			"isDeleted": false,
			"id": "ZFEK4nx3cnDnQNChta0OU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -631.1336575211106,
			"y": -893.0998466367316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 165,
			"height": 21,
			"seed": 1389398679,
			"groupIds": [
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 402,
			"versionNonce": 2053612569,
			"isDeleted": false,
			"id": "oU_Nf5Zl431_3USyqZN_Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -635.1336575211106,
			"y": -917.0998466367316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 56,
			"height": 25,
			"seed": 90639991,
			"groupIds": [
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 333,
			"versionNonce": 2087126519,
			"isDeleted": false,
			"id": "3ll-BB6Lm0QsP08bHmqhu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -619.1336575211106,
			"y": -871.0998466367316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1,
			"height": 23,
			"seed": 402170009,
			"groupIds": [
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1,
					23
				]
			]
		},
		{
			"type": "line",
			"version": 377,
			"versionNonce": 636336377,
			"isDeleted": false,
			"id": "pzx_f3crBgCtT6rxJlAtb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -479.13365752111065,
			"y": -871.0998466367316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2,
			"height": 23,
			"seed": 1042479287,
			"groupIds": [
				"0d9VixpbIWBFdLLSr9U-s"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2,
					23
				]
			]
		},
		{
			"type": "rectangle",
			"version": 615,
			"versionNonce": 1134636823,
			"isDeleted": false,
			"id": "dEThy05WuETIUs1IPEHx7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -716.3962837837372,
			"y": 23.70823417134983,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 246.63636363636377,
			"height": 144,
			"seed": 1010434071,
			"groupIds": [
				"VyGbb07sekH3PXCajRF-E"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 568,
			"versionNonce": 631124441,
			"isDeleted": false,
			"id": "UQ-qKDvbkDNZGklAekx5O",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -728.5781019655552,
			"y": 39.70823417134983,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 130,
			"height": 124.81818181818187,
			"seed": 1748571673,
			"groupIds": [
				"VyGbb07sekH3PXCajRF-E"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					130,
					-124.81818181818187
				]
			]
		},
		{
			"type": "line",
			"version": 595,
			"versionNonce": 804860983,
			"isDeleted": false,
			"id": "KBe-m9tCthmv4MKn-FZtc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -603.8508292382827,
			"y": -82.29176582865023,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 161.18181818181847,
			"height": 119.36363636363649,
			"seed": 746845527,
			"groupIds": [
				"VyGbb07sekH3PXCajRF-E"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.246998379406364,
					46.22646073984123
				],
				[
					161.18181818181847,
					119.36363636363649
				]
			]
		},
		{
			"type": "rectangle",
			"version": 640,
			"versionNonce": 1317834425,
			"isDeleted": false,
			"id": "UkIAo0IoMKRm5BEXw1Yao",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -697.305374692828,
			"y": 335.5264159895318,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 246.63636363636377,
			"height": 144,
			"seed": 1694112697,
			"groupIds": [
				"t0Na-c8cNtfdhJSHYQ4km"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 593,
			"versionNonce": 424908119,
			"isDeleted": false,
			"id": "bz16EEJ5DJjgidEaY5Hzz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -709.487192874646,
			"y": 351.5264159895318,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 130,
			"height": 124.81818181818187,
			"seed": 336681047,
			"groupIds": [
				"t0Na-c8cNtfdhJSHYQ4km"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					130,
					-124.81818181818187
				]
			]
		},
		{
			"type": "line",
			"version": 620,
			"versionNonce": 123490201,
			"isDeleted": false,
			"id": "UMNmoIdeVm_VrY-YqNzpq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.7599201473735,
			"y": 229.5264159895318,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 161.18181818181847,
			"height": 119.36363636363649,
			"seed": 1922055321,
			"groupIds": [
				"t0Na-c8cNtfdhJSHYQ4km"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.246998379406364,
					46.22646073984123
				],
				[
					161.18181818181847,
					119.36363636363649
				]
			]
		},
		{
			"type": "rectangle",
			"version": 831,
			"versionNonce": 1728369271,
			"isDeleted": false,
			"id": "KAzX6hzbKxdvXBNb4W1Cs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -690.9417383291916,
			"y": 660.0718705349866,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 246.63636363636377,
			"height": 144,
			"seed": 1706260663,
			"groupIds": [
				"cemf9dRR8Ln8lN6bGtSma"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "_jnOhHx9Cui5wQst9fzeu",
					"type": "arrow"
				}
			],
			"updated": 1679055973341,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 782,
			"versionNonce": 373355641,
			"isDeleted": false,
			"id": "ykpxa-KThqJopLnIQDFcA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -703.1235565110096,
			"y": 676.0718705349868,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 130,
			"height": 124.81818181818187,
			"seed": 468111929,
			"groupIds": [
				"cemf9dRR8Ln8lN6bGtSma"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					130,
					-124.81818181818187
				]
			]
		},
		{
			"type": "line",
			"version": 851,
			"versionNonce": 567372695,
			"isDeleted": false,
			"id": "hYyQTBXyKZ9ZJYl0uzgep",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -578.3962837837371,
			"y": 554.0718705349775,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 161.18181818181847,
			"height": 119.36363636363649,
			"seed": 407980503,
			"groupIds": [
				"cemf9dRR8Ln8lN6bGtSma"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.246998379406364,
					46.22646073984123
				],
				[
					161.18181818181847,
					119.36363636363649
				]
			]
		},
		{
			"type": "line",
			"version": 4072,
			"versionNonce": 788397401,
			"isDeleted": false,
			"id": "vKH2kxlIR7-DTHnaAlvJf",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -664.8774897838463,
			"y": 87.23119588945843,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 5.985206883798873,
			"height": 30.6681212978069,
			"seed": 725902905,
			"groupIds": [
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					5.985206883798873,
					30.6681212978069
				]
			]
		},
		{
			"type": "line",
			"version": 4050,
			"versionNonce": 1173217463,
			"isDeleted": false,
			"id": "W2701XkKUb3V1OclAhzjt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -658.0414683296943,
			"y": 116.72240730861785,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 31.969843632199503,
			"height": 3.19636727268836,
			"seed": 1715926487,
			"groupIds": [
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					31.969843632199503,
					3.19636727268836
				]
			]
		},
		{
			"type": "line",
			"version": 4095,
			"versionNonce": 1088875065,
			"isDeleted": false,
			"id": "P7umsW4o_ogAC27By1sD3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -626.8676487362255,
			"y": 110.8862439292322,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 31.289920296468715,
			"height": 6.092815027506178,
			"seed": 1043150617,
			"groupIds": [
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-31.289920296468715,
					6.092815027506178
				]
			]
		},
		{
			"type": "line",
			"version": 4837,
			"versionNonce": 1425977815,
			"isDeleted": false,
			"id": "n3vHQO-rHaVKPmdtubguW",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -652.1197842006444,
			"y": 108.64259483636937,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.4031208686701,
			"height": 10.633736963170932,
			"seed": 1874338551,
			"groupIds": [
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-11.4031208686701,
					-10.633736963170932
				]
			]
		},
		{
			"type": "line",
			"version": 4384,
			"versionNonce": 81738521,
			"isDeleted": false,
			"id": "BFssgiz3sGVGdyCm0iZaD",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -661.7084485537008,
			"y": 95.18924539582218,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 12.887171348208224,
			"height": 4.030840578266512,
			"seed": 562621433,
			"groupIds": [
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12.887171348208224,
					4.030840578266512
				]
			]
		},
		{
			"type": "ellipse",
			"version": 4454,
			"versionNonce": 672685815,
			"isDeleted": false,
			"id": "hKnN5pPuecYBEvwzWd8SD",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2319026939503512,
			"x": -675.6619862834498,
			"y": 62.70746208456052,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.186309587294165,
			"height": 25.022402559557463,
			"seed": 1273930935,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 5977,
			"versionNonce": 1264218105,
			"isDeleted": false,
			"id": "JeA55V_8vxZAFR1yHC2Jd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -654.8432503009403,
			"y": 66.35084341133262,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 22.420689460586402,
			"height": 16.93878129469369,
			"seed": 1220979735,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.695651191722263,
					7.296085206991138
				],
				[
					-12.009767178845223,
					10.697150025383115
				],
				[
					-18.919056928056804,
					11.002134547825259
				],
				[
					-22.420689460586402,
					16.93878129469369
				]
			]
		},
		{
			"type": "line",
			"version": 5153,
			"versionNonce": 29321239,
			"isDeleted": false,
			"id": "UBOI-dVGvY46GHTPRQjWD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -657.121217300774,
			"y": 66.35542816973981,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 19.843133057738967,
			"height": 10.715289756556256,
			"seed": 224068825,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.129518338954064,
					6.543753196139666
				],
				[
					-14.044114326042454,
					9.812382366111738
				],
				[
					-19.843133057738967,
					10.715289756556256
				]
			]
		},
		{
			"type": "line",
			"version": 5187,
			"versionNonce": 173803737,
			"isDeleted": false,
			"id": "abD2Y4C7PQD7caSoKxpJE",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -659.1113312799142,
			"y": 65.0012304553349,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 17.57928979699632,
			"height": 8.712696685560589,
			"seed": 1298600247,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-10.10749391683938,
					3.5373688279037054
				],
				[
					-17.57928979699632,
					8.712696685560589
				]
			]
		},
		{
			"type": "line",
			"version": 5107,
			"versionNonce": 1609059639,
			"isDeleted": false,
			"id": "PBJcT-OjDgMP2OmVHj-x2",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -657.6286435715845,
			"y": 65.97726041376569,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 18.58442944998732,
			"height": 9.452066566730116,
			"seed": 1832321465,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.060492778118189,
					4.914087049167385
				],
				[
					-14.361614966776944,
					7.944665073819593
				],
				[
					-18.58442944998732,
					9.452066566730116
				]
			]
		},
		{
			"type": "line",
			"version": 5139,
			"versionNonce": 729253305,
			"isDeleted": false,
			"id": "nllMC5jimwTrnZxgpr2lM",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -658.80942680384,
			"y": 65.64088654410824,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 17.93353361653893,
			"height": 8.548696785277032,
			"seed": 1727910487,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-8.42694363203788,
					4.555270744298665
				],
				[
					-17.93353361653893,
					8.548696785277032
				]
			]
		},
		{
			"type": "line",
			"version": 5178,
			"versionNonce": 234327639,
			"isDeleted": false,
			"id": "Bgdf2OfXGu0FyLRpQ7JpK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -660.9013113217931,
			"y": 65.06023734341358,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 15.191820566135297,
			"height": 7.351737533373122,
			"seed": 1849713305,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.604125463290602,
					2.7566110245317317
				],
				[
					-15.191820566135297,
					7.351737533373122
				]
			]
		},
		{
			"type": "line",
			"version": 3690,
			"versionNonce": 433088153,
			"isDeleted": false,
			"id": "xU3GxaQr7RjbKxunrrJ5p",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -675.6778628880653,
			"y": 80.74128941664566,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 7.2787869310018065,
			"height": 6.520627038002394,
			"seed": 1583312759,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.093046516230056,
					-0.41410670757717677
				],
				[
					-6.342668493818478,
					-3.1727466163075224
				],
				[
					-5.188480221539935,
					-6.3997282175092
				],
				[
					-0.9801843624098207,
					-6.520627038002394
				],
				[
					0.9361184371833282,
					-2.9953530198829266
				]
			]
		},
		{
			"type": "line",
			"version": 2680,
			"versionNonce": 1992403831,
			"isDeleted": false,
			"id": "Di67SuFaoiRFXen7uwVpP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -682.5134653436693,
			"y": 76.275283756134,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.918915208318781,
			"height": 3.6286594580739364,
			"seed": 1294641017,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.1021281463932713,
					2.616273073383216
				],
				[
					6.918915208318781,
					3.6286594580739364
				]
			]
		},
		{
			"type": "line",
			"version": 2877,
			"versionNonce": 270150521,
			"isDeleted": false,
			"id": "yJ7kVF8-qng0mAcpwMi6B",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -682.2025807250178,
			"y": 75.51638632816054,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.556826160612685,
			"height": 3.3235876680443655,
			"seed": 1842374807,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.8145272708882505,
					0.46269221487818074
				],
				[
					5.556826160612685,
					3.3235876680443655
				]
			]
		},
		{
			"type": "line",
			"version": 2980,
			"versionNonce": 915088535,
			"isDeleted": false,
			"id": "K5XByon12P7zm2I9wrLx5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -681.8240961848951,
			"y": 76.56078096144284,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.556826160612685,
			"height": 3.3235876680443655,
			"seed": 1681477721,
			"groupIds": [
				"BCgmlAKNGHUg9ugfAZRlO",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.4925495140934517,
					1.5880681514317032
				],
				[
					5.556826160612685,
					3.3235876680443655
				]
			]
		},
		{
			"type": "rectangle",
			"version": 763,
			"versionNonce": 647517273,
			"isDeleted": false,
			"id": "K92yr7AbJ7vfoK6uwBsS-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.076710878753897,
			"x": -686.6531057381801,
			"y": 88.27654191605637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 13.64031221841103,
			"height": 36.595959610371054,
			"seed": 969934425,
			"groupIds": [
				"dJiyFT72TK6DV-ZcZmG6b",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 697,
			"versionNonce": 1829271991,
			"isDeleted": false,
			"id": "XAIY9Fcq30QxEPQ0f8BSb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -683.9915814028803,
			"y": 124.87250152642736,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52.56510562216935,
			"height": 12.974931134586118,
			"seed": 1197258937,
			"groupIds": [
				"dJiyFT72TK6DV-ZcZmG6b",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 612,
			"versionNonce": 555639097,
			"isDeleted": false,
			"id": "mzmXeW8HvTAmUdADTZj3a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -677.6704611065436,
			"y": 138.51281374483852,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.323048670599401,
			"height": 15.303764927973361,
			"seed": 1285152313,
			"groupIds": [
				"dJiyFT72TK6DV-ZcZmG6b",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.323048670599401,
					15.303764927973361
				]
			]
		},
		{
			"type": "line",
			"version": 615,
			"versionNonce": 1331571415,
			"isDeleted": false,
			"id": "NK-A0U7yMvBCIvuq84iAM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -640.74181095426,
			"y": 138.18012320292593,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.980716257373926,
			"height": 15.303764927973361,
			"seed": 152142839,
			"groupIds": [
				"dJiyFT72TK6DV-ZcZmG6b",
				"jGgvYQtOrHN-IMXhLaXYC"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.980716257373926,
					15.303764927973361
				]
			]
		},
		{
			"type": "line",
			"version": 4120,
			"versionNonce": 2098188825,
			"isDeleted": false,
			"id": "avpXnGZMtDOGDo4JBcRhO",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -640.3320352383918,
			"y": 395.41301407127696,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 5.985206883798873,
			"height": 30.6681212978069,
			"seed": 1796355447,
			"groupIds": [
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					5.985206883798873,
					30.6681212978069
				]
			]
		},
		{
			"type": "line",
			"version": 4098,
			"versionNonce": 2048964599,
			"isDeleted": false,
			"id": "iVn5QK8Au0IAYs-I_p1WN",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -633.4960137842398,
			"y": 424.90422549043626,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 31.969843632199503,
			"height": 3.19636727268836,
			"seed": 779043193,
			"groupIds": [
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					31.969843632199503,
					3.19636727268836
				]
			]
		},
		{
			"type": "line",
			"version": 4143,
			"versionNonce": 1063266041,
			"isDeleted": false,
			"id": "6PFbz0VkFmtW8aB_i2JRI",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -602.322194190771,
			"y": 419.0680621110506,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 31.289920296468715,
			"height": 6.092815027506178,
			"seed": 607809175,
			"groupIds": [
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-31.289920296468715,
					6.092815027506178
				]
			]
		},
		{
			"type": "line",
			"version": 4885,
			"versionNonce": 55877911,
			"isDeleted": false,
			"id": "0Ah1jz3xD2J_kxBlQE-s4",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -627.5743296551899,
			"y": 416.8244130181878,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.4031208686701,
			"height": 10.633736963170932,
			"seed": 635087449,
			"groupIds": [
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-11.4031208686701,
					-10.633736963170932
				]
			]
		},
		{
			"type": "line",
			"version": 4432,
			"versionNonce": 43179993,
			"isDeleted": false,
			"id": "rIWX1StnExK599wJhLSwG",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -637.1629940082463,
			"y": 403.3710635776407,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 12.887171348208224,
			"height": 4.030840578266512,
			"seed": 977175479,
			"groupIds": [
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12.887171348208224,
					4.030840578266512
				]
			]
		},
		{
			"type": "ellipse",
			"version": 4502,
			"versionNonce": 1282303543,
			"isDeleted": false,
			"id": "fyEzSTdhuyBwwZ6MhZVpo",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2319026939503512,
			"x": -651.1165317379953,
			"y": 370.889280266379,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.186309587294165,
			"height": 25.022402559557463,
			"seed": 1906702137,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 6025,
			"versionNonce": 1153137849,
			"isDeleted": false,
			"id": "uC0jEhtwFO890sEdl9p2W",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -630.2977957554858,
			"y": 374.5326615931511,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 22.420689460586402,
			"height": 16.93878129469369,
			"seed": 1564669143,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.695651191722263,
					7.296085206991138
				],
				[
					-12.009767178845223,
					10.697150025383115
				],
				[
					-18.919056928056804,
					11.002134547825259
				],
				[
					-22.420689460586402,
					16.93878129469369
				]
			]
		},
		{
			"type": "line",
			"version": 5201,
			"versionNonce": 340952919,
			"isDeleted": false,
			"id": "bW4-pBUw0MPC9BaIcLYWP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -632.5757627553195,
			"y": 374.5372463515583,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 19.843133057738967,
			"height": 10.715289756556256,
			"seed": 1144301593,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.129518338954064,
					6.543753196139666
				],
				[
					-14.044114326042454,
					9.812382366111738
				],
				[
					-19.843133057738967,
					10.715289756556256
				]
			]
		},
		{
			"type": "line",
			"version": 5235,
			"versionNonce": 1971158425,
			"isDeleted": false,
			"id": "DWby-BD0ELvJmTTTOVs_9",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -634.5658767344597,
			"y": 373.1830486371534,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 17.57928979699632,
			"height": 8.712696685560589,
			"seed": 1155285495,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-10.10749391683938,
					3.5373688279037054
				],
				[
					-17.57928979699632,
					8.712696685560589
				]
			]
		},
		{
			"type": "line",
			"version": 5155,
			"versionNonce": 1230341239,
			"isDeleted": false,
			"id": "cGTQqQMfBdV4zBi_OVold",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -633.08318902613,
			"y": 374.15907859558416,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 18.58442944998732,
			"height": 9.452066566730116,
			"seed": 930757881,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.060492778118189,
					4.914087049167385
				],
				[
					-14.361614966776944,
					7.944665073819593
				],
				[
					-18.58442944998732,
					9.452066566730116
				]
			]
		},
		{
			"type": "line",
			"version": 5187,
			"versionNonce": 1141662329,
			"isDeleted": false,
			"id": "2T_dFCrOYDHhoZPVJ2K4l",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -634.2639722583855,
			"y": 373.8227047259267,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 17.93353361653893,
			"height": 8.548696785277032,
			"seed": 1108273943,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-8.42694363203788,
					4.555270744298665
				],
				[
					-17.93353361653893,
					8.548696785277032
				]
			]
		},
		{
			"type": "line",
			"version": 5226,
			"versionNonce": 456908183,
			"isDeleted": false,
			"id": "q7MSDsU8gVeEP1Pb9grQ_",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -636.3558567763386,
			"y": 373.24205552523205,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 15.191820566135297,
			"height": 7.351737533373122,
			"seed": 1526347225,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.604125463290602,
					2.7566110245317317
				],
				[
					-15.191820566135297,
					7.351737533373122
				]
			]
		},
		{
			"type": "line",
			"version": 3738,
			"versionNonce": 757836633,
			"isDeleted": false,
			"id": "wAUCs79uhs2Pgt1z3tWKy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -651.1324083426108,
			"y": 388.92310759846407,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 7.2787869310018065,
			"height": 6.520627038002394,
			"seed": 290418743,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.093046516230056,
					-0.41410670757717677
				],
				[
					-6.342668493818478,
					-3.1727466163075224
				],
				[
					-5.188480221539935,
					-6.3997282175092
				],
				[
					-0.9801843624098207,
					-6.520627038002394
				],
				[
					0.9361184371833282,
					-2.9953530198829266
				]
			]
		},
		{
			"type": "line",
			"version": 2728,
			"versionNonce": 1295651511,
			"isDeleted": false,
			"id": "ZwJao7cr3UEtL6McRRDRN",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -657.9680107982148,
			"y": 384.4571019379524,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.918915208318781,
			"height": 3.6286594580739364,
			"seed": 29889209,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.1021281463932713,
					2.616273073383216
				],
				[
					6.918915208318781,
					3.6286594580739364
				]
			]
		},
		{
			"type": "line",
			"version": 2925,
			"versionNonce": 1227806777,
			"isDeleted": false,
			"id": "_EXAr3TnV8dwqrskB4lvI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -657.6571261795633,
			"y": 383.69820450997906,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.556826160612685,
			"height": 3.3235876680443655,
			"seed": 1820479831,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.8145272708882505,
					0.46269221487818074
				],
				[
					5.556826160612685,
					3.3235876680443655
				]
			]
		},
		{
			"type": "line",
			"version": 3028,
			"versionNonce": 1207215063,
			"isDeleted": false,
			"id": "rtZpjxEJ5HufRm-FZz-gE",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -657.2786416394406,
			"y": 384.7425991432614,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.556826160612685,
			"height": 3.3235876680443655,
			"seed": 1351046041,
			"groupIds": [
				"5dbSfAJLUfRU3XHJa_nEG",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.4925495140934517,
					1.5880681514317032
				],
				[
					5.556826160612685,
					3.3235876680443655
				]
			]
		},
		{
			"type": "rectangle",
			"version": 811,
			"versionNonce": 1509517593,
			"isDeleted": false,
			"id": "wlnem46qu0PodFi580yG_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.076710878753897,
			"x": -662.1076511927256,
			"y": 396.4583600978748,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 13.64031221841103,
			"height": 36.595959610371054,
			"seed": 1560022647,
			"groupIds": [
				"kL9q_5Vw_SF_9He3Yfl-o",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 745,
			"versionNonce": 1803555063,
			"isDeleted": false,
			"id": "256x_AdurHtKKznKDEkdn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -659.4461268574258,
			"y": 433.05431970824577,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52.56510562216935,
			"height": 12.974931134586118,
			"seed": 191592569,
			"groupIds": [
				"kL9q_5Vw_SF_9He3Yfl-o",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 660,
			"versionNonce": 419356153,
			"isDeleted": false,
			"id": "gzm6-7-osPydXa_WMwtjF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -653.1250065610891,
			"y": 446.69463192665705,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.323048670599401,
			"height": 15.303764927973361,
			"seed": 1300309911,
			"groupIds": [
				"kL9q_5Vw_SF_9He3Yfl-o",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.323048670599401,
					15.303764927973361
				]
			]
		},
		{
			"type": "line",
			"version": 663,
			"versionNonce": 559995415,
			"isDeleted": false,
			"id": "3Oy8NSfiTEYs1ceR_OHKB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -616.1963564088055,
			"y": 446.36194138474445,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.980716257373926,
			"height": 15.303764927973361,
			"seed": 607650137,
			"groupIds": [
				"kL9q_5Vw_SF_9He3Yfl-o",
				"XcEUboGZ7XfeWR7Pz9wiE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.980716257373926,
					15.303764927973361
				]
			]
		},
		{
			"type": "line",
			"version": 4309,
			"versionNonce": 1162000089,
			"isDeleted": false,
			"id": "A1kf50SbLlK3mZqkO0UZE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -633.9683988747554,
			"y": 719.9584686167318,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 5.985206883798873,
			"height": 30.6681212978069,
			"seed": 1201808153,
			"groupIds": [
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					5.985206883798873,
					30.6681212978069
				]
			]
		},
		{
			"type": "line",
			"version": 4287,
			"versionNonce": 780894007,
			"isDeleted": false,
			"id": "AWqPh8aoOCq75Py7oYnot",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -627.1323774206035,
			"y": 749.4496800358911,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 31.969843632199503,
			"height": 3.19636727268836,
			"seed": 358086391,
			"groupIds": [
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					31.969843632199503,
					3.19636727268836
				]
			]
		},
		{
			"type": "line",
			"version": 4332,
			"versionNonce": 1901622201,
			"isDeleted": false,
			"id": "TlvnzGY6PJsnnbUHjX9-I",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -595.9585578271347,
			"y": 743.6135166565055,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 31.289920296468715,
			"height": 6.092815027506178,
			"seed": 92297209,
			"groupIds": [
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-31.289920296468715,
					6.092815027506178
				]
			]
		},
		{
			"type": "line",
			"version": 5074,
			"versionNonce": 1164214359,
			"isDeleted": false,
			"id": "IHE7vTs7OPJa6ZeHUEFEq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -621.2106932915535,
			"y": 741.3698675636426,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.4031208686701,
			"height": 10.633736963170932,
			"seed": 1397489687,
			"groupIds": [
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-11.4031208686701,
					-10.633736963170932
				]
			]
		},
		{
			"type": "line",
			"version": 4621,
			"versionNonce": 291738777,
			"isDeleted": false,
			"id": "dMxotuU8Nq5RQps6MMq86",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -630.7993576446099,
			"y": 727.9165181230956,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 12.887171348208224,
			"height": 4.030840578266512,
			"seed": 1468330201,
			"groupIds": [
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12.887171348208224,
					4.030840578266512
				]
			]
		},
		{
			"type": "ellipse",
			"version": 4691,
			"versionNonce": 1472224631,
			"isDeleted": false,
			"id": "OHkVqjtojShaHv5wooqC4",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2319026939503512,
			"x": -644.7528953743589,
			"y": 695.434734811834,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.186309587294165,
			"height": 25.022402559557463,
			"seed": 69330231,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 6214,
			"versionNonce": 1226283385,
			"isDeleted": false,
			"id": "WQrY62mAbefXnEK7IV-N5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -623.9341593918494,
			"y": 699.078116138606,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 22.420689460586402,
			"height": 16.93878129469369,
			"seed": 860057017,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.695651191722263,
					7.296085206991138
				],
				[
					-12.009767178845223,
					10.697150025383115
				],
				[
					-18.919056928056804,
					11.002134547825259
				],
				[
					-22.420689460586402,
					16.93878129469369
				]
			]
		},
		{
			"type": "line",
			"version": 5390,
			"versionNonce": 686003863,
			"isDeleted": false,
			"id": "xQe60-Xveejksn8iKwK2j",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -626.2121263916831,
			"y": 699.0827008970132,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 19.843133057738967,
			"height": 10.715289756556256,
			"seed": 658384471,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973342,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.129518338954064,
					6.543753196139666
				],
				[
					-14.044114326042454,
					9.812382366111738
				],
				[
					-19.843133057738967,
					10.715289756556256
				]
			]
		},
		{
			"type": "line",
			"version": 5424,
			"versionNonce": 2042102361,
			"isDeleted": false,
			"id": "y1YNhIcutoh1OixqqNRGD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -628.2022403708233,
			"y": 697.7285031826084,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 17.57928979699632,
			"height": 8.712696685560589,
			"seed": 266292889,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-10.10749391683938,
					3.5373688279037054
				],
				[
					-17.57928979699632,
					8.712696685560589
				]
			]
		},
		{
			"type": "line",
			"version": 5344,
			"versionNonce": 528657335,
			"isDeleted": false,
			"id": "Rl1xzh52dnCNtMXPbw5Vw",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -626.7195526624936,
			"y": 698.7045331410391,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 18.58442944998732,
			"height": 9.452066566730116,
			"seed": 1534411639,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.060492778118189,
					4.914087049167385
				],
				[
					-14.361614966776944,
					7.944665073819593
				],
				[
					-18.58442944998732,
					9.452066566730116
				]
			]
		},
		{
			"type": "line",
			"version": 5376,
			"versionNonce": 270028601,
			"isDeleted": false,
			"id": "wmKe1EO6GjsDElJ5lnv9G",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -627.9003358947491,
			"y": 698.3681592713817,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 17.93353361653893,
			"height": 8.548696785277032,
			"seed": 873206649,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-8.42694363203788,
					4.555270744298665
				],
				[
					-17.93353361653893,
					8.548696785277032
				]
			]
		},
		{
			"type": "line",
			"version": 5415,
			"versionNonce": 1472339159,
			"isDeleted": false,
			"id": "zFoCxHDMkChuG1u1-5_wv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -629.9922204127022,
			"y": 697.787510070687,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 15.191820566135297,
			"height": 7.351737533373122,
			"seed": 1896594583,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.604125463290602,
					2.7566110245317317
				],
				[
					-15.191820566135297,
					7.351737533373122
				]
			]
		},
		{
			"type": "line",
			"version": 3927,
			"versionNonce": 312213529,
			"isDeleted": false,
			"id": "b1xnlI7ZYopPV8x5JNmPd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -644.7687719789744,
			"y": 713.4685621439189,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 7.2787869310018065,
			"height": 6.520627038002394,
			"seed": 1141718105,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.093046516230056,
					-0.41410670757717677
				],
				[
					-6.342668493818478,
					-3.1727466163075224
				],
				[
					-5.188480221539935,
					-6.3997282175092
				],
				[
					-0.9801843624098207,
					-6.520627038002394
				],
				[
					0.9361184371833282,
					-2.9953530198829266
				]
			]
		},
		{
			"type": "line",
			"version": 2917,
			"versionNonce": 1966500343,
			"isDeleted": false,
			"id": "Ktig-SjZ_CPRCt3_d3j_g",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -651.6043744345784,
			"y": 709.0025564834073,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.918915208318781,
			"height": 3.6286594580739364,
			"seed": 1001787831,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.1021281463932713,
					2.616273073383216
				],
				[
					6.918915208318781,
					3.6286594580739364
				]
			]
		},
		{
			"type": "line",
			"version": 3114,
			"versionNonce": 1865848057,
			"isDeleted": false,
			"id": "3FO8hD3uxirRcrKUt-twE",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -651.2934898159269,
			"y": 708.2436590554339,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.556826160612685,
			"height": 3.3235876680443655,
			"seed": 263604537,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.8145272708882505,
					0.46269221487818074
				],
				[
					5.556826160612685,
					3.3235876680443655
				]
			]
		},
		{
			"type": "line",
			"version": 3217,
			"versionNonce": 887362327,
			"isDeleted": false,
			"id": "OC0VJuPjOZxaZpWoORb_1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -650.9150052758042,
			"y": 709.2880536887162,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.556826160612685,
			"height": 3.3235876680443655,
			"seed": 613991127,
			"groupIds": [
				"Xo-ti6drY4JK9u222rgpo",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.4925495140934517,
					1.5880681514317032
				],
				[
					5.556826160612685,
					3.3235876680443655
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1000,
			"versionNonce": 158043609,
			"isDeleted": false,
			"id": "PI452y1uwgupvEyN29Pz1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.076710878753897,
			"x": -655.7440148290892,
			"y": 721.0038146433296,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 13.64031221841103,
			"height": 36.595959610371054,
			"seed": 543865369,
			"groupIds": [
				"0qIOLhGuTZ0G4Q4MFFkOF",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 934,
			"versionNonce": 1061132343,
			"isDeleted": false,
			"id": "Y2aOe9ovye-q8iO1gKFaE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -653.0824904937895,
			"y": 757.5997742537006,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52.56510562216935,
			"height": 12.974931134586118,
			"seed": 2085113847,
			"groupIds": [
				"0qIOLhGuTZ0G4Q4MFFkOF",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 849,
			"versionNonce": 139356857,
			"isDeleted": false,
			"id": "3En_hrMIhpTI5QVzYUXR-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -646.7613701974527,
			"y": 771.2400864721119,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.323048670599401,
			"height": 15.303764927973361,
			"seed": 119410425,
			"groupIds": [
				"0qIOLhGuTZ0G4Q4MFFkOF",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.323048670599401,
					15.303764927973361
				]
			]
		},
		{
			"type": "line",
			"version": 852,
			"versionNonce": 976058711,
			"isDeleted": false,
			"id": "yyC5aVURlHGFoC_QO3o4O",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -609.8327200451691,
			"y": 770.9073959301993,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.980716257373926,
			"height": 15.303764927973361,
			"seed": 214513943,
			"groupIds": [
				"0qIOLhGuTZ0G4Q4MFFkOF",
				"2BpleO3JNzbuNwBABFI_S"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.980716257373926,
					15.303764927973361
				]
			]
		},
		{
			"type": "line",
			"version": 4149,
			"versionNonce": 1686285209,
			"isDeleted": false,
			"id": "F52W9b08koa31tQXC35nU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -613.787625552517,
			"y": -248.05914013797923,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 6.508971330615937,
			"height": 33.35188342972993,
			"seed": 1995982393,
			"groupIds": [
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					6.508971330615937,
					33.35188342972993
				]
			]
		},
		{
			"type": "line",
			"version": 4127,
			"versionNonce": 453129847,
			"isDeleted": false,
			"id": "I7R25kM8ZFpIYKgdvdSMc",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -606.3533850117274,
			"y": -215.98715777224942,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 34.7675192664658,
			"height": 3.4760808346264547,
			"seed": 1212224983,
			"groupIds": [
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					34.7675192664658,
					3.4760808346264547
				]
			]
		},
		{
			"type": "line",
			"version": 4172,
			"versionNonce": 909889657,
			"isDeleted": false,
			"id": "kTRCNyAchUem2UvM1jh6T",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -572.4515497136144,
			"y": -222.33404282647183,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 34.02809595408742,
			"height": 6.6259962448636935,
			"seed": 677713689,
			"groupIds": [
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-34.02809595408742,
					6.6259962448636935
				]
			]
		},
		{
			"type": "line",
			"version": 4914,
			"versionNonce": 948064151,
			"isDeleted": false,
			"id": "ilZmVwuGDUPFqMcS44pKX",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -599.9134953014348,
			"y": -224.7740332737423,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 12.401006056220423,
			"height": 11.564293494673537,
			"seed": 1299071735,
			"groupIds": [
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-12.401006056220423,
					-11.564293494673537
				]
			]
		},
		{
			"type": "line",
			"version": 4461,
			"versionNonce": 1128094041,
			"isDeleted": false,
			"id": "_1-s4Y6yIRbHYUwb4D3V2",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -610.3412620578163,
			"y": -239.4046830590175,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.014925543389328,
			"height": 4.3835787586957125,
			"seed": 969198585,
			"groupIds": [
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.014925543389328,
					4.3835787586957125
				]
			]
		},
		{
			"type": "ellipse",
			"version": 4536,
			"versionNonce": 484590775,
			"isDeleted": false,
			"id": "rcxXyKZ-6t57Eiuvvtd08",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2319026939503512,
			"x": -625.5158715252767,
			"y": -274.72894175967707,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 29.56537896257845,
			"height": 27.212108795129073,
			"seed": 1253624855,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 6059,
			"versionNonce": 1289406009,
			"isDeleted": false,
			"id": "5R4LeUD-AhD10Ai3Gf7Wd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -602.8752914616837,
			"y": -270.7667287463471,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 24.38272022085441,
			"height": 18.4210911942204,
			"seed": 1931142361,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.10656683701693,
					7.934564395189955
				],
				[
					-13.060739882872639,
					11.633255823284587
				],
				[
					-20.574660414888122,
					11.964929489942794
				],
				[
					-24.38272022085441,
					18.4210911942204
				]
			]
		},
		{
			"type": "line",
			"version": 5235,
			"versionNonce": 398890455,
			"isDeleted": false,
			"id": "ualMmfqTjNba0B7Hx-4DX",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -605.3526029701866,
			"y": -270.76174277650335,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 21.579602291114476,
			"height": 11.652982959278944,
			"seed": 202715447,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-6.665911456917538,
					7.116395936720772
				],
				[
					-15.27311240644739,
					10.671062295097252
				],
				[
					-21.579602291114476,
					11.652982959278944
				]
			]
		},
		{
			"type": "line",
			"version": 5269,
			"versionNonce": 502765337,
			"isDeleted": false,
			"id": "_mr17nnw89QclWrarZnO1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -607.5168714886142,
			"y": -272.2344461049224,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 19.117650487732647,
			"height": 9.475143305768489,
			"seed": 1341841849,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-10.991999007948293,
					3.8469233785325305
				],
				[
					-19.117650487732647,
					9.475143305768489
				]
			]
		},
		{
			"type": "line",
			"version": 5189,
			"versionNonce": 272876279,
			"isDeleted": false,
			"id": "seGdFwCDZPZO9Qy8KKJ5_",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -605.9044340285327,
			"y": -271.17300392913984,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20.21074974254589,
			"height": 10.27921532076938,
			"seed": 1793585751,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-7.67835531252732,
					5.344117979574325
				],
				[
					-15.618397474802672,
					8.639901376978901
				],
				[
					-20.21074974254589,
					10.27921532076938
				]
			]
		},
		{
			"type": "line",
			"version": 5221,
			"versionNonce": 1493650425,
			"isDeleted": false,
			"id": "uaRkRu_DGXpihAfZ278iz",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -607.1885474026631,
			"y": -271.53881381950396,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 19.502894124287987,
			"height": 9.296791801819806,
			"seed": 227033753,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.164384050637322,
					4.9539017202717455
				],
				[
					-19.502894124287987,
					9.296791801819806
				]
			]
		},
		{
			"type": "line",
			"version": 5260,
			"versionNonce": 383667223,
			"isDeleted": false,
			"id": "aVG-1n4ndTkXam1HK02A-",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.975989471159853,
			"x": -609.4634923826222,
			"y": -272.17027553400163,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 16.521254226399286,
			"height": 7.995086847284794,
			"seed": 537235319,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-10.444580865769405,
					2.997841591224738
				],
				[
					-16.521254226399286,
					7.995086847284794
				]
			]
		},
		{
			"type": "line",
			"version": 3772,
			"versionNonce": 101541081,
			"isDeleted": false,
			"id": "rLLm1KhxiQnjUa2EiJ0wY",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -625.5331374888892,
			"y": -255.1169772336795,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 7.915752349980889,
			"height": 7.0912460123780985,
			"seed": 2021033849,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.45122832781834,
					-0.45034511584414894
				],
				[
					-6.897714345951213,
					-3.450393138582167
				],
				[
					-5.642523252268272,
					-6.959767356456347
				],
				[
					-1.0659601309544269,
					-7.0912460123780985
				],
				[
					1.0180380040296757,
					-3.257475858397914
				]
			]
		},
		{
			"type": "line",
			"version": 2762,
			"versionNonce": 931836215,
			"isDeleted": false,
			"id": "ICMYhO6L2NTJPS36s7P06",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -632.9669223646385,
			"y": -259.9738022977096,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 7.524388313428749,
			"height": 3.9462028363805683,
			"seed": 1437763735,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.3735948582540396,
					2.845222689596514
				],
				[
					7.524388313428749,
					3.9462028363805683
				]
			]
		},
		{
			"type": "line",
			"version": 2959,
			"versionNonce": 1620926905,
			"isDeleted": false,
			"id": "_0vY8JKCYvrGRBo1BR4T9",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -632.628832285345,
			"y": -260.79911071184773,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.043103082459802,
			"height": 3.614434265363051,
			"seed": 2064199769,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					4.148335910204206,
					0.5031823327098999
				],
				[
					6.043103082459802,
					3.614434265363051
				]
			]
		},
		{
			"type": "line",
			"version": 3063,
			"versionNonce": 195916375,
			"isDeleted": false,
			"id": "0Kt79kl48ip_aJljgbdje",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 70,
			"angle": 5.975989471159853,
			"x": -632.2172266268324,
			"y": -259.6633212800263,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.043103082459802,
			"height": 3.614434265363051,
			"seed": 2040749495,
			"groupIds": [
				"TMCQov7RR8QgQEdA_UPl2",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.7106721024616385,
					1.7270397280189587
				],
				[
					6.043103082459802,
					3.614434265363051
				]
			]
		},
		{
			"type": "rectangle",
			"version": 841,
			"versionNonce": 1708835481,
			"isDeleted": false,
			"id": "LW_fBsvU5jZAJG0CwNquU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.076710878753897,
			"x": -637.4688219931822,
			"y": -246.92231605657315,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 14.833973644355511,
			"height": 39.798465875100156,
			"seed": 1796455737,
			"groupIds": [
				"2EOAs2e9i8XLP3gSydCXL",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 775,
			"versionNonce": 203100023,
			"isDeleted": false,
			"id": "x2_MivimUmmpCm2n6mH2I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -634.5743881113566,
			"y": -207.12385018147296,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57.165069166052966,
			"height": 14.110365173899163,
			"seed": 1325174487,
			"groupIds": [
				"2EOAs2e9i8XLP3gSydCXL",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 689,
			"versionNonce": 578357113,
			"isDeleted": false,
			"id": "o3b78kobhxboc_K9dnlc2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -627.7001076420212,
			"y": -192.28987653711755,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.788867763650904,
			"height": 16.64299482049644,
			"seed": 402239001,
			"groupIds": [
				"2EOAs2e9i8XLP3gSydCXL",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.788867763650904,
					16.64299482049644
				]
			]
		},
		{
			"type": "line",
			"version": 692,
			"versionNonce": 588777623,
			"isDeleted": false,
			"id": "vcKceq-rqm0yW_b0dCxqC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -587.5398375316927,
			"y": -192.65168077234574,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.854127056845499,
			"height": 16.64299482049644,
			"seed": 1079155703,
			"groupIds": [
				"2EOAs2e9i8XLP3gSydCXL",
				"cVcCzz8cKH9KQ9Vcarpnw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973343,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					10.854127056845499,
					16.64299482049644
				]
			]
		},
		{
			"type": "ellipse",
			"version": 2669,
			"versionNonce": 1086042201,
			"isDeleted": false,
			"id": "ZXCvJrPlAcmxsnB1LiMBJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -640.9262816418809,
			"y": -508.8645371530014,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36.498905240366796,
			"height": 40.05011448636824,
			"seed": 735666137,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2635,
			"versionNonce": 2119753143,
			"isDeleted": false,
			"id": "GD83EKtVvNdI-Vt7Aiuz-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -624.5458125967718,
			"y": -468.6938441561946,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.0566829361112067,
			"height": 46.76991195935305,
			"seed": 550495799,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.0566829361112067,
					46.76991195935305
				]
			]
		},
		{
			"type": "line",
			"version": 2588,
			"versionNonce": 1450589497,
			"isDeleted": false,
			"id": "fafrECtp3ulgCIQTKLb8z",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -626.5155370702792,
			"y": -420.6265314008115,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.514071392436083,
			"height": 28.522738352519166,
			"seed": 20053177,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.514071392436083,
					28.522738352519166
				]
			]
		},
		{
			"type": "line",
			"version": 2564,
			"versionNonce": 553782999,
			"isDeleted": false,
			"id": "4AiBjeBFWxgU3VzdAY-jK",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -629.0699081987186,
			"y": -422.5422852812562,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 15.841168568978583,
			"height": 26.497455155890602,
			"seed": 1619265367,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.841168568978583,
					26.497455155890602
				]
			]
		},
		{
			"type": "line",
			"version": 2541,
			"versionNonce": 1930178073,
			"isDeleted": false,
			"id": "OBGq1dmlj7AlmOn1vnzJb",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -642.266848013704,
			"y": -459.5731537361446,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.984200788666975,
			"height": 17.26200678056687,
			"seed": 1596194201,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.984200788666975,
					17.26200678056687
				]
			]
		},
		{
			"type": "line",
			"version": 2561,
			"versionNonce": 900209655,
			"isDeleted": false,
			"id": "bsmWtgfZN_e70jsm7-5Z-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -623.1392824039444,
			"y": -442.66592416529545,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 25.91655997546225,
			"height": 14.616578729156648,
			"seed": 324469879,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					25.91655997546225,
					-14.616578729156648
				]
			]
		},
		{
			"type": "line",
			"version": 2796,
			"versionNonce": 1836122873,
			"isDeleted": false,
			"id": "9y9REANWZ0Fjl0gLEFVMk",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -607.7125970316432,
			"y": -498.29082250692426,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.583633103250932,
			"height": 14.92947142039958,
			"seed": 887284345,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.425222749336143,
					7.05715888861724
				],
				[
					-25.07277824481478,
					2.913836503468637
				],
				[
					-30.583633103250932,
					14.92947142039958
				]
			]
		},
		{
			"type": "line",
			"version": 3067,
			"versionNonce": 542082327,
			"isDeleted": false,
			"id": "BsYKxaXvft0kPNDh_m4k2",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -638.487566914748,
			"y": -498.16544769565394,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.32026048196458,
			"height": 35.15075777191929,
			"seed": 688741783,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.2131437827080298,
					-5.470158972353492
				],
				[
					-6.2545415684244405,
					-6.677498171449353
				],
				[
					-12.32026048196458,
					2.8199539465701275
				],
				[
					-8.971582602423409,
					28.473259600469934
				],
				[
					-4.777380268267563,
					15.852427339973978
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "rectangle",
			"version": 2030,
			"versionNonce": 1915239385,
			"isDeleted": false,
			"id": "0YeHC5PlGYAnU3ah_SSdF",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.32340402082123276,
			"x": -649.9236070026564,
			"y": -469.89212434218746,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.261582049196969,
			"height": 21.33728820314335,
			"seed": 1060252505,
			"groupIds": [
				"YcQxRtfNCHVKSJacOmabh"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2618,
			"versionNonce": 1349306935,
			"isDeleted": false,
			"id": "vtAbPaueCxG57fSeUr2E5",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -527.8151705307698,
			"y": -289.30898159744595,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36.498905240366796,
			"height": 40.05011448636824,
			"seed": 1614993335,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2579,
			"versionNonce": 1363499193,
			"isDeleted": false,
			"id": "8hR6oV6MhnpomxZuQpX6U",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -511.43470148566075,
			"y": -249.1382886006392,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.0566829361112067,
			"height": 46.76991195935305,
			"seed": 1539367737,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.0566829361112067,
					46.76991195935305
				]
			]
		},
		{
			"type": "line",
			"version": 2532,
			"versionNonce": 1390701399,
			"isDeleted": false,
			"id": "5F7F-gs13DkfXLxHsk0IX",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -513.4044259591681,
			"y": -201.0709758452562,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.514071392436083,
			"height": 28.522738352519166,
			"seed": 1738328279,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.514071392436083,
					28.522738352519166
				]
			]
		},
		{
			"type": "line",
			"version": 2508,
			"versionNonce": 208394649,
			"isDeleted": false,
			"id": "mLsqmEpMYjuSg4dzVSRAs",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -515.9587970876075,
			"y": -202.98672972570097,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 15.841168568978583,
			"height": 26.497455155890602,
			"seed": 68293657,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.841168568978583,
					26.497455155890602
				]
			]
		},
		{
			"type": "line",
			"version": 2505,
			"versionNonce": 604694647,
			"isDeleted": false,
			"id": "GRzvmFcZhti8J9m2RUU8g",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -535.8224035692597,
			"y": -223.3509315139226,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 24.65086745533366,
			"height": 0.5953401139002423,
			"seed": 215717367,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					24.65086745533366,
					0.5953401139002423
				]
			]
		},
		{
			"type": "line",
			"version": 2505,
			"versionNonce": 617561721,
			"isDeleted": false,
			"id": "wJu5yjpcuryDtoVeQefVY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -510.02817129283346,
			"y": -223.11036860974008,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 25.91655997546225,
			"height": 14.616578729156648,
			"seed": 1892296953,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					25.91655997546225,
					-14.616578729156648
				]
			]
		},
		{
			"type": "line",
			"version": 2760,
			"versionNonce": 1101316503,
			"isDeleted": false,
			"id": "bmIkPr_kZ431wEqD8HEFO",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -493.93481925386544,
			"y": -278.7352669513688,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 35.91696643658432,
			"height": 9.596138087066265,
			"seed": 1996734231,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.425222749336143,
					7.05715888861724
				],
				[
					-25.07277824481478,
					2.913836503468637
				],
				[
					-35.91696643658432,
					9.596138087066265
				]
			]
		},
		{
			"type": "line",
			"version": 3064,
			"versionNonce": 691210073,
			"isDeleted": false,
			"id": "j4K7n-mJkb_GDzmMYw0MS",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -482.0431224703035,
			"y": -276.6098921400985,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.32026048196458,
			"height": 35.15075777191929,
			"seed": 996975065,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.2131437827080298,
					-5.470158972353492
				],
				[
					-6.2545415684244405,
					-6.677498171449353
				],
				[
					-12.32026048196458,
					2.8199539465701275
				],
				[
					-8.971582602423409,
					28.473259600469934
				],
				[
					-4.777380268267563,
					15.852427339973978
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1988,
			"versionNonce": 2095478455,
			"isDeleted": false,
			"id": "L0XtB0PF5MwheCRUgdePe",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.32340402082123276,
			"x": -542.8124958915454,
			"y": -237.66990211996534,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.261582049196969,
			"height": 21.33728820314335,
			"seed": 2022294583,
			"groupIds": [
				"dsF451JTE4Arl9YdBsGKY"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2495,
			"versionNonce": 65713209,
			"isDeleted": false,
			"id": "cmpYPKM__jkoUuUAMaVQV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -647.9262816418808,
			"y": -748.4200927085571,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36.498905240366796,
			"height": 40.05011448636824,
			"seed": 1890699479,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2460,
			"versionNonce": 208963543,
			"isDeleted": false,
			"id": "3ov8DkEqS8UJ-lbiB3Dim",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -631.5458125967718,
			"y": -708.2493997117504,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.0566829361112067,
			"height": 46.76991195935305,
			"seed": 46994457,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.0566829361112067,
					46.76991195935305
				]
			]
		},
		{
			"type": "line",
			"version": 2413,
			"versionNonce": 148489497,
			"isDeleted": false,
			"id": "fFdi8nF9KLFJAgCZej8db",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -633.5155370702792,
			"y": -660.1820869563672,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.514071392436083,
			"height": 28.522738352519166,
			"seed": 726701559,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.514071392436083,
					28.522738352519166
				]
			]
		},
		{
			"type": "line",
			"version": 2389,
			"versionNonce": 1583576311,
			"isDeleted": false,
			"id": "TcBxTOdQtnzm5PrO6bPXu",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -636.0699081987186,
			"y": -662.097840836812,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 15.841168568978583,
			"height": 26.497455155890602,
			"seed": 1613048057,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.841168568978583,
					26.497455155890602
				]
			]
		},
		{
			"type": "line",
			"version": 2366,
			"versionNonce": 1131657721,
			"isDeleted": false,
			"id": "__appgPPpeiq2UPNNsABh",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -649.266848013704,
			"y": -699.1287092917004,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.984200788666975,
			"height": 17.26200678056687,
			"seed": 2128133911,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.984200788666975,
					17.26200678056687
				]
			]
		},
		{
			"type": "line",
			"version": 2386,
			"versionNonce": 708296215,
			"isDeleted": false,
			"id": "XrHVDz258Z4svHyPoxDe7",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -630.1392824039444,
			"y": -682.2214797208512,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 25.91655997546225,
			"height": 14.616578729156648,
			"seed": 124232153,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					25.91655997546225,
					-14.616578729156648
				]
			]
		},
		{
			"type": "line",
			"version": 2621,
			"versionNonce": 79434457,
			"isDeleted": false,
			"id": "IepKvztwhgM_6chy3wUsh",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -614.7125970316431,
			"y": -737.84637806248,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.583633103250932,
			"height": 14.92947142039958,
			"seed": 1035912247,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.425222749336143,
					7.05715888861724
				],
				[
					-25.07277824481478,
					2.913836503468637
				],
				[
					-30.583633103250932,
					14.92947142039958
				]
			]
		},
		{
			"type": "line",
			"version": 2892,
			"versionNonce": 1122362167,
			"isDeleted": false,
			"id": "CPV61SbqtZObIW-x_N03e",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -645.4875669147478,
			"y": -737.7210032512097,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.32026048196458,
			"height": 35.15075777191929,
			"seed": 363331257,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.2131437827080298,
					-5.470158972353492
				],
				[
					-6.2545415684244405,
					-6.677498171449353
				],
				[
					-12.32026048196458,
					2.8199539465701275
				],
				[
					-8.971582602423409,
					28.473259600469934
				],
				[
					-4.777380268267563,
					15.852427339973978
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1855,
			"versionNonce": 826691513,
			"isDeleted": false,
			"id": "2T0LIX_FDEPuWuXQhN_hV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.32340402082123276,
			"x": -656.9236070026564,
			"y": -709.4476798977432,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.261582049196969,
			"height": 21.33728820314335,
			"seed": 2011637079,
			"groupIds": [
				"kySB_QVFxpS7cDhTiQ9XH"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2885,
			"versionNonce": 684876887,
			"isDeleted": false,
			"id": "JI9STic1lL8y9OW7H90i-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -285.1990089146076,
			"y": 347.03445274598903,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36.498905240366796,
			"height": 40.05011448636824,
			"seed": 294096601,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2850,
			"versionNonce": 1328935065,
			"isDeleted": false,
			"id": "rQEJfhTfRim8BFF7yxK3b",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -268.81853986949875,
			"y": 387.2051457427958,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.0566829361112067,
			"height": 46.76991195935305,
			"seed": 1470113591,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.0566829361112067,
					46.76991195935305
				]
			]
		},
		{
			"type": "line",
			"version": 2803,
			"versionNonce": 1540473207,
			"isDeleted": false,
			"id": "CzYFoYg1qS9AmWZXyfDGX",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -270.78826434300606,
			"y": 435.27245849817893,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.514071392436083,
			"height": 28.522738352519166,
			"seed": 256003001,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.514071392436083,
					28.522738352519166
				]
			]
		},
		{
			"type": "line",
			"version": 2779,
			"versionNonce": 1413379449,
			"isDeleted": false,
			"id": "83Hy0knuFY0_e9qYK2dHJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -273.34263547144553,
			"y": 433.3567046177342,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 15.841168568978583,
			"height": 26.497455155890602,
			"seed": 899950679,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.841168568978583,
					26.497455155890602
				]
			]
		},
		{
			"type": "line",
			"version": 2756,
			"versionNonce": 1831369367,
			"isDeleted": false,
			"id": "Pvv_wd0Lcl8Vb4wLu7TrZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -286.53957528643093,
			"y": 396.3258361628458,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.984200788666975,
			"height": 17.26200678056687,
			"seed": 72510617,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.984200788666975,
					17.26200678056687
				]
			]
		},
		{
			"type": "line",
			"version": 2776,
			"versionNonce": 866344537,
			"isDeleted": false,
			"id": "NDWOUURbrX2fsSLG6BPWP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -267.41200967667135,
			"y": 413.23306573369496,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 25.91655997546225,
			"height": 14.616578729156648,
			"seed": 1909130615,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					25.91655997546225,
					-14.616578729156648
				]
			]
		},
		{
			"type": "line",
			"version": 3011,
			"versionNonce": 1368068023,
			"isDeleted": false,
			"id": "v6TppWhg3ShRkUUaIv_oJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -251.98532430437,
			"y": 357.6081673920662,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.583633103250932,
			"height": 14.92947142039958,
			"seed": 678130041,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.425222749336143,
					7.05715888861724
				],
				[
					-25.07277824481478,
					2.913836503468637
				],
				[
					-30.583633103250932,
					14.92947142039958
				]
			]
		},
		{
			"type": "line",
			"version": 3282,
			"versionNonce": 741878585,
			"isDeleted": false,
			"id": "6Xv_Vd1Xu8zGp5uic2Lpx",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -282.76029418747464,
			"y": 357.73354220333647,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.32026048196458,
			"height": 35.15075777191929,
			"seed": 2069446295,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.2131437827080298,
					-5.470158972353492
				],
				[
					-6.2545415684244405,
					-6.677498171449353
				],
				[
					-12.32026048196458,
					2.8199539465701275
				],
				[
					-8.971582602423409,
					28.473259600469934
				],
				[
					-4.777380268267563,
					15.852427339973978
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "rectangle",
			"version": 2245,
			"versionNonce": 1931346135,
			"isDeleted": false,
			"id": "c3IePZFmOSDw5AgbvhMkS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.32340402082123276,
			"x": -294.19633427538326,
			"y": 386.00686555680295,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.261582049196969,
			"height": 21.33728820314335,
			"seed": 1892735577,
			"groupIds": [
				"lw5eShGeztqbwcsybQCox"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973344,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 609,
			"versionNonce": 1794283831,
			"isDeleted": false,
			"id": "VFOLxWvPLxF6rQKw9z4Dv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -813.0108505035666,
			"y": -1018.0998466367316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 381.0000000000002,
			"height": 192.00000000000006,
			"seed": 1710409111,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679056140327,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 829,
			"versionNonce": 58052087,
			"isDeleted": false,
			"id": "kpyiBFJ6MBtK6PeRtrLhs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -739.0714565641726,
			"y": -788.8069173438024,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 306.5555555555558,
			"height": 192.00000000000006,
			"seed": 1335374169,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 867,
			"versionNonce": 1913614585,
			"isDeleted": false,
			"id": "ezOsWFj_Gm36AETXeENhi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -732.4047898975059,
			"y": -338.8069173438023,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 306.5555555555558,
			"height": 192.00000000000006,
			"seed": 2081917719,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 880,
			"versionNonce": 227997463,
			"isDeleted": false,
			"id": "OEeZ3lcWEKJWWjMTLnICI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -735.7381232308393,
			"y": -562.1402506771357,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 306.5555555555558,
			"height": 192.00000000000006,
			"seed": 571141369,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 443,
			"versionNonce": 1959324121,
			"isDeleted": false,
			"id": "lOuYBn9m1X6wPQlx9W3eI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -784.9473584400744,
			"y": -1006.433179970065,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.920634920634983,
			"height": 49.333333333333314,
			"seed": 1994415799,
			"groupIds": [
				"zxt3-BS5BjEGEeyPAJnBL"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 441,
			"versionNonce": 1207303223,
			"isDeleted": false,
			"id": "4x_8Vd_8-D2SE9WRdXAvh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -802.566406059122,
			"y": -989.9887355256205,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 49.333333333333314,
			"height": 15.269841269841248,
			"seed": 92298103,
			"groupIds": [
				"zxt3-BS5BjEGEeyPAJnBL"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 608,
			"versionNonce": 1470121657,
			"isDeleted": false,
			"id": "Z94PzXbU8kvg27EPK29mO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -711.0079645006804,
			"y": -777.1402506771358,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.920634920634983,
			"height": 49.333333333333314,
			"seed": 941268537,
			"groupIds": [
				"IRhSDb4MEuaPIo61IIFYZ"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 606,
			"versionNonce": 645356887,
			"isDeleted": false,
			"id": "RKatzGdEgk7VWW9bkUr8p",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -728.627012119728,
			"y": -760.6958062326913,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 49.333333333333314,
			"height": 15.269841269841248,
			"seed": 1662008791,
			"groupIds": [
				"IRhSDb4MEuaPIo61IIFYZ"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 646,
			"versionNonce": 624494489,
			"isDeleted": false,
			"id": "n1QJnP9r5AjW8wtbRmGpl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -704.3412978340136,
			"y": -327.1402506771356,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.920634920634983,
			"height": 49.333333333333314,
			"seed": 457938393,
			"groupIds": [
				"6IRFLn-Z7sbZtbZJjOxxU"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 644,
			"versionNonce": 745511543,
			"isDeleted": false,
			"id": "3rbnlynz93lEQUMRzzodu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -721.9603454530612,
			"y": -310.69580623269127,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 49.333333333333314,
			"height": 15.269841269841248,
			"seed": 1094979639,
			"groupIds": [
				"6IRFLn-Z7sbZtbZJjOxxU"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 656,
			"versionNonce": 1204202617,
			"isDeleted": false,
			"id": "guKOpz4BJJM6B4QhXR4Xl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -711.0079645006804,
			"y": -551.5846951215802,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.920634920634983,
			"height": 49.333333333333314,
			"seed": 587528249,
			"groupIds": [
				"-n7FjluN1oAzNO8FT10OS"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 654,
			"versionNonce": 2124624791,
			"isDeleted": false,
			"id": "rvqmPXfjCUkc8MUYbHfd5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -728.627012119728,
			"y": -535.1402506771358,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 49.333333333333314,
			"height": 15.269841269841248,
			"seed": 907051991,
			"groupIds": [
				"-n7FjluN1oAzNO8FT10OS"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 931,
			"versionNonce": 386708825,
			"isDeleted": false,
			"id": "9EGFKqLS0w4Gka_lBzNLq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -724.5341780532099,
			"y": -909.9311556785669,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.03174603174608,
			"height": 30.666666666666686,
			"seed": 86081593,
			"groupIds": [
				"JA9hEIfW_4uhrAxmF9N3F",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 929,
			"versionNonce": 893823159,
			"isDeleted": false,
			"id": "opC506oeEcBN0GhBm60Uy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -735.4865590055908,
			"y": -899.7089334563447,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.666666666666686,
			"height": 9.492063492063489,
			"seed": 2011200471,
			"groupIds": [
				"JA9hEIfW_4uhrAxmF9N3F",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 3205,
			"versionNonce": 643736121,
			"isDeleted": false,
			"id": "NxPkmy_mBtotJG78F_YUC",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -707.2712518935803,
			"y": -969.5244420213019,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 41.45030810518929,
			"height": 38.151051443572015,
			"seed": 1403664887,
			"groupIds": [
				"ZWJqRpFUzNR7tFYa-tumm",
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3269,
			"versionNonce": 1845393879,
			"isDeleted": false,
			"id": "UuK0Cn5KDaW1QdAGE3efV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -688.9042169443235,
			"y": -931.5848376146124,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.033894694926427,
			"height": 46.25169691744879,
			"seed": 1051182329,
			"groupIds": [
				"ZWJqRpFUzNR7tFYa-tumm",
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.033894694926427,
					46.25169691744879
				]
			]
		},
		{
			"type": "line",
			"version": 3222,
			"versionNonce": 1386214169,
			"isDeleted": false,
			"id": "gi4xune_vTEpCBFEjJDq4",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -690.7566981129557,
			"y": -884.1485930730254,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.308933732763165,
			"height": 28.206703717614968,
			"seed": 878568215,
			"groupIds": [
				"ZWJqRpFUzNR7tFYa-tumm",
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.308933732763165,
					28.206703717614968
				]
			]
		},
		{
			"type": "line",
			"version": 3199,
			"versionNonce": 501163767,
			"isDeleted": false,
			"id": "LDXdkhXobC-rvgj-vF8hD",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -693.3617996517521,
			"y": -885.9747383558401,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 15.665646925043903,
			"height": 26.20386085009203,
			"seed": 859225561,
			"groupIds": [
				"ZWJqRpFUzNR7tFYa-tumm",
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.665646925043903,
					26.20386085009203
				]
			]
		},
		{
			"type": "line",
			"version": 3260,
			"versionNonce": 272902137,
			"isDeleted": false,
			"id": "UGvaANgIWshFZj4m_hBZ0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -714.1891907971715,
			"y": -905.302674914391,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 24.206723328724483,
			"height": 15.504281014140858,
			"seed": 1325361207,
			"groupIds": [
				"ZWJqRpFUzNR7tFYa-tumm",
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					24.206723328724483,
					-15.504281014140858
				]
			]
		},
		{
			"type": "line",
			"version": 3303,
			"versionNonce": 594358295,
			"isDeleted": false,
			"id": "4AbZ0cZw-68ivb4y6Um2c",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -690.5572860606558,
			"y": -921.6960181366894,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.316880406545398,
			"height": 20.633908278345753,
			"seed": 825465529,
			"groupIds": [
				"ZWJqRpFUzNR7tFYa-tumm",
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.316880406545398,
					20.633908278345753
				]
			]
		},
		{
			"type": "text",
			"version": 1333,
			"versionNonce": 2035204313,
			"isDeleted": false,
			"id": "RFlznL3S",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -697.8700286266467,
			"y": -950.9442193842633,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 34.93359375,
			"height": 13.2,
			"seed": 1634945367,
			"groupIds": [
				"B8clt0VmnyJc9EqDloBQR",
				"p_9ERPK_XA58eWYGohbib"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"fontSize": 11.386913991573158,
			"fontFamily": 1,
			"text": "｡◕‿◕｡",
			"rawText": "｡◕‿◕｡",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "｡◕‿◕｡"
		},
		{
			"type": "rectangle",
			"version": 1416,
			"versionNonce": 412947767,
			"isDeleted": false,
			"id": "hyo8ZULxu41kXmnpjeM6T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -563.2614507804825,
			"y": -693.6382263856376,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.03174603174608,
			"height": 30.666666666666686,
			"seed": 321144407,
			"groupIds": [
				"p8r0yitA1U-Kt5-1athtY"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1414,
			"versionNonce": 458440121,
			"isDeleted": false,
			"id": "-7cK0oRvcMZQiep5RCMcF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -574.2138317328635,
			"y": -683.4160041634154,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.666666666666686,
			"height": 9.492063492063489,
			"seed": 1424699033,
			"groupIds": [
				"p8r0yitA1U-Kt5-1athtY"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2243,
			"versionNonce": 1691571799,
			"isDeleted": false,
			"id": "O6xjMhNhcWzdNLKHfT54S",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -558.572333708163,
			"y": -510.00219621666565,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44.169759425803804,
			"height": 40.6540467643249,
			"seed": 602356313,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2307,
			"versionNonce": 91561625,
			"isDeleted": false,
			"id": "d6y7ZUG-HDcHB-OBfZMrJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -538.3057894363459,
			"y": -469.5743139558259,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.167333452488185,
			"height": 49.28615538139134,
			"seed": 1560474551,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.167333452488185,
					49.28615538139134
				]
			]
		},
		{
			"type": "line",
			"version": 2261,
			"versionNonce": 249852791,
			"isDeleted": false,
			"id": "K7R0VRLebk17iavqiOCwV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -540.8899592181345,
			"y": -418.3104600385092,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 19.510137204936473,
			"height": 30.057275189373165,
			"seed": 530614073,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					19.510137204936473,
					30.057275189373165
				]
			]
		},
		{
			"type": "line",
			"version": 2265,
			"versionNonce": 375907193,
			"isDeleted": false,
			"id": "YjnvhiRHqW7B8gRTmbyFq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -541.497536524165,
			"y": -419.1721911313303,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.783346090897325,
			"height": 25.733119709460734,
			"seed": 234448087,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-18.783346090897325,
					25.733119709460734
				]
			]
		},
		{
			"type": "line",
			"version": 2214,
			"versionNonce": 1326771351,
			"isDeleted": false,
			"id": "B5Xyz5XGnSeAYZebx7RvE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -557.8383795624844,
			"y": -459.88607174987135,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.951759311642757,
			"height": 18.19071092374616,
			"seed": 1952266265,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.951759311642757,
					18.19071092374616
				]
			]
		},
		{
			"type": "line",
			"version": 2234,
			"versionNonce": 175049817,
			"isDeleted": false,
			"id": "LuPiNwNbAVZGRGs7PNPsJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -537.3377553994991,
			"y": -441.5624544894489,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 27.310883180876726,
			"height": 15.402957589820515,
			"seed": 1967436279,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					27.310883180876726,
					-15.402957589820515
				]
			]
		},
		{
			"type": "line",
			"version": 2254,
			"versionNonce": 1629045175,
			"isDeleted": false,
			"id": "oOg4usRwnUXWH6y9gnG2W",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -565.653242086913,
			"y": -506.1461505818451,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 63.46164769486781,
			"height": 12.911229185001785,
			"seed": 1947258105,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					63.46164769486781,
					12.911229185001785
				]
			]
		},
		{
			"type": "rectangle",
			"version": 2686,
			"versionNonce": 1230903609,
			"isDeleted": false,
			"id": "irV022OeUVltBrkEmR5bm",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.1875122815022081,
			"x": -545.4552064963949,
			"y": -547.3930153474234,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 32.71500022666033,
			"height": 45.980903261711745,
			"seed": 736713495,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1943,
			"versionNonce": 370537175,
			"isDeleted": false,
			"id": "L6HEZygUn0FEaEGlA5u25",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -536.2805144379212,
			"y": -480.81612270975177,
			"strokeColor": "#000000",
			"backgroundColor": "#000",
			"width": 53.20883302704749,
			"height": 12.438499241734945,
			"seed": 1715389913,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					16.057917597112322,
					6.049076792861201
				],
				[
					22.482826275609803,
					5.465194911879904
				],
				[
					27.39425009598468,
					2.016358930953765
				],
				[
					23.850013402912772,
					10.166502906931791
				],
				[
					15.774030333735844,
					10.636936235909024
				],
				[
					-0.1619724876934452,
					6.53463659543896
				],
				[
					-16.495069149918784,
					8.744614388479818
				],
				[
					-25.81458293106281,
					-1.8015630058259184
				],
				[
					-16.48461931200311,
					3.816409289419604
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "ellipse",
			"version": 1304,
			"versionNonce": 1956153881,
			"isDeleted": false,
			"id": "BgYPqXoIk7Qi22VF7U0Bq",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -553.7806163309809,
			"y": -497.482652308123,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 14.47032432846386,
			"height": 11.522877502139076,
			"seed": 911990839,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1144,
			"versionNonce": 647987191,
			"isDeleted": false,
			"id": "1VyoE07wngXEyfJ4-8TBm",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -547.2143301334812,
			"y": -492.9380172196881,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.7549734432242013,
			"height": 0.9913792688802648,
			"seed": 1442489017,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1145,
			"versionNonce": 890363641,
			"isDeleted": false,
			"id": "_zCdjHIpY74SCVB18j7lI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -527.3524277811752,
			"y": -491.2259814822757,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.7625994376002037,
			"height": 1.2964190439203462,
			"seed": 377536855,
			"groupIds": [
				"h_329lO6JdTjVuEyvnwUG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 701,
			"versionNonce": 1153067287,
			"isDeleted": false,
			"id": "dAC2TKxw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -468.6442348992806,
			"y": -556.7622747857793,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 45.737998962402344,
			"height": 74.39999999999999,
			"seed": 7845849,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"fontSize": 62.91703567129895,
			"fontFamily": 1,
			"text": "€",
			"rawText": "€",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "€"
		},
		{
			"type": "ellipse",
			"version": 2997,
			"versionNonce": 1229821913,
			"isDeleted": false,
			"id": "mP2q-8HelsJrTeMSB7-yB",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -543.1883436776089,
			"y": -754.4432804267601,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 42.83119599154594,
			"height": 39.42202691271702,
			"seed": 618548921,
			"groupIds": [
				"vSiAHYz0kbk-c6ncSSsk7",
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3060,
			"versionNonce": 1843080759,
			"isDeleted": false,
			"id": "lPDQA6ouH21SzGBlgrtrw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -524.2094238659921,
			"y": -715.2397447603702,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 2.101652467419253,
			"height": 47.79253969802992,
			"seed": 1509807447,
			"groupIds": [
				"vSiAHYz0kbk-c6ncSSsk7",
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973345,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.101652467419253,
					47.79253969802992
				]
			]
		},
		{
			"type": "line",
			"version": 3013,
			"versionNonce": 1398748345,
			"isDeleted": false,
			"id": "JN3J6zfZ3jfIfAWrsOPVT",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -526.1236191429726,
			"y": -666.2231950665151,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 18.918882993924726,
			"height": 29.146390230411463,
			"seed": 762711961,
			"groupIds": [
				"vSiAHYz0kbk-c6ncSSsk7",
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.918882993924726,
					29.146390230411463
				]
			]
		},
		{
			"type": "line",
			"version": 2990,
			"versionNonce": 2095468375,
			"isDeleted": false,
			"id": "jk0ZcxvKpOfecsl1WhtsG",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -528.8155078088639,
			"y": -668.1101770961488,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 16.187536943710015,
			"height": 27.076824060204753,
			"seed": 409408119,
			"groupIds": [
				"vSiAHYz0kbk-c6ncSSsk7",
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-16.187536943710015,
					27.076824060204753
				]
			]
		},
		{
			"type": "line",
			"version": 3051,
			"versionNonce": 1726625177,
			"isDeleted": false,
			"id": "k7lLnGf6uxoX2Qg47KL8w",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -550.3367488543646,
			"y": -688.0820102789237,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 25.013153305751302,
			"height": 16.020795240881096,
			"seed": 1394783353,
			"groupIds": [
				"vSiAHYz0kbk-c6ncSSsk7",
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					25.013153305751302,
					-16.020795240881096
				]
			]
		},
		{
			"type": "line",
			"version": 3094,
			"versionNonce": 2083540087,
			"isDeleted": false,
			"id": "g8RDgfO4g1749Dy7BbJW3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -525.917563818282,
			"y": -705.0214862106609,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.893780108284684,
			"height": 21.32131243267567,
			"seed": 1827384215,
			"groupIds": [
				"vSiAHYz0kbk-c6ncSSsk7",
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.893780108284684,
					21.32131243267567
				]
			]
		},
		{
			"type": "text",
			"version": 1082,
			"versionNonce": 1461852793,
			"isDeleted": false,
			"id": "bBMNajye",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -542.1755193463277,
			"y": -749.3841611131186,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 38.109375,
			"height": 13.2,
			"seed": 1772600665,
			"groupIds": [
				"CIA-hUN6ZH9fd9HcoleAA"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"fontSize": 11.766261029333293,
			"fontFamily": 1,
			"text": "｡◕‿◕｡",
			"rawText": "｡◕‿◕｡",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "｡◕‿◕｡"
		},
		{
			"type": "rectangle",
			"version": 1620,
			"versionNonce": 930981271,
			"isDeleted": false,
			"id": "rdN4-iaju4nmV3Q1uAsxf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -524.1705416895733,
			"y": 412.7254099779997,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.03174603174608,
			"height": 30.666666666666686,
			"seed": 2021040983,
			"groupIds": [
				"BkW8P421SKL_ZtBCZJyG6",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1618,
			"versionNonce": 1154114393,
			"isDeleted": false,
			"id": "Tn6q2NWOIfIcHVpXSI5Nd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -535.1229226419542,
			"y": 422.94763220022185,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.666666666666686,
			"height": 9.492063492063489,
			"seed": 1782129049,
			"groupIds": [
				"BkW8P421SKL_ZtBCZJyG6",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2194,
			"versionNonce": 235068087,
			"isDeleted": false,
			"id": "4fFQSyhnbwkms_QC54k_a",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -565.1027158708466,
			"y": 354.48995871829203,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 39.92241276545124,
			"height": 36.74476964805884,
			"seed": 589571735,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2257,
			"versionNonce": 1815515193,
			"isDeleted": false,
			"id": "tvD3s6UPaBM_zwhOdpD-U",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -547.3623379425862,
			"y": 391.2449933037325,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 1.9589235217807446,
			"height": 44.546818102174086,
			"seed": 763916889,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.9589235217807446,
					44.546818102174086
				]
			]
		},
		{
			"type": "line",
			"version": 2210,
			"versionNonce": 73690071,
			"isDeleted": false,
			"id": "dnH37qs9GonGzfpgYtBK2",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -549.0462576431398,
			"y": 436.76707653741585,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.63405009969413,
			"height": 27.166979451871327,
			"seed": 590429111,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.63405009969413,
					27.166979451871327
				]
			]
		},
		{
			"type": "line",
			"version": 2224,
			"versionNonce": 860496153,
			"isDeleted": false,
			"id": "aAz4MnM_kSfkHMZuf3RK9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -549.1521740756721,
			"y": 435.5590488177746,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.57438556648872,
			"height": 24.39340617494452,
			"seed": 1348124473,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-17.57438556648872,
					24.39340617494452
				]
			]
		},
		{
			"type": "line",
			"version": 2197,
			"versionNonce": 381081847,
			"isDeleted": false,
			"id": "b7_zKWP5nBI82N1C8kVXA",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -564.4170702911538,
			"y": 399.6870889136811,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.99454839941563,
			"height": 15.596942345268781,
			"seed": 119450839,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.99454839941563,
					15.596942345268781
				]
			]
		},
		{
			"type": "line",
			"version": 2209,
			"versionNonce": 2004391417,
			"isDeleted": false,
			"id": "2RJdc5cmCCIKNphgytuat",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -548.1035593643862,
			"y": 415.40229779355093,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 26.798604282604586,
			"height": 13.467248605026825,
			"seed": 17854489,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					26.798604282604586,
					-13.467248605026825
				]
			]
		},
		{
			"type": "line",
			"version": 2205,
			"versionNonce": 1249813015,
			"isDeleted": false,
			"id": "SFbpBr6SyBaDFFyzO1X0Z",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -571.6190720615941,
			"y": 357.7119315761353,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57.35920066094075,
			"height": 11.66969047451636,
			"seed": 713095671,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					57.35920066094075,
					11.66969047451636
				]
			]
		},
		{
			"type": "rectangle",
			"version": 2512,
			"versionNonce": 465923801,
			"isDeleted": false,
			"id": "i4unijWgQ7DrmWP9TAfMn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.1875122815022081,
			"x": -558.7932432078408,
			"y": 350.0759068772359,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 34.330844028819804,
			"height": 11.842596955377553,
			"seed": 1973224697,
			"groupIds": [
				"TPq3h5qZX3QKFiUMUHlId",
				"nNKYcY2m0Ar2rNhzKMHSD"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1951,
			"versionNonce": 11552567,
			"isDeleted": false,
			"id": "0AuHsXGdXCjNrhqK1Dvmg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -161.4432689623002,
			"y": 408.17995543254494,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 8.03174603174608,
			"height": 30.666666666666686,
			"seed": 1493797431,
			"groupIds": [
				"isfMMNuR4i6mLcTEoGd55",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1949,
			"versionNonce": 1455696825,
			"isDeleted": false,
			"id": "skSnANJDuLdYtIg_GKfzR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -172.39564991468117,
			"y": 418.4021776547671,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 30.666666666666686,
			"height": 9.492063492063489,
			"seed": 1037342905,
			"groupIds": [
				"isfMMNuR4i6mLcTEoGd55",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2525,
			"versionNonce": 128993367,
			"isDeleted": false,
			"id": "SN2iY-Hlz9Hxjdn86C0Gb",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -202.37544314357356,
			"y": 349.94450417283724,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 39.92241276545124,
			"height": 36.74476964805884,
			"seed": 703146839,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2588,
			"versionNonce": 1083722905,
			"isDeleted": false,
			"id": "VZRQcpQ3k6acCaSgdUGBI",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -184.63506521531318,
			"y": 386.69953875827775,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 1.9589235217807446,
			"height": 44.546818102174086,
			"seed": 622008729,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.9589235217807446,
					44.546818102174086
				]
			]
		},
		{
			"type": "line",
			"version": 2541,
			"versionNonce": 1834165623,
			"isDeleted": false,
			"id": "zDTBviDCgAnbHVP8VXlsR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -186.31898491586676,
			"y": 432.2216219919611,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.63405009969413,
			"height": 27.166979451871327,
			"seed": 1014474871,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.63405009969413,
					27.166979451871327
				]
			]
		},
		{
			"type": "line",
			"version": 2555,
			"versionNonce": 552948089,
			"isDeleted": false,
			"id": "UBebxb0QSq6jE2mKaoyaU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -186.424901348399,
			"y": 431.0135942723199,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.57438556648872,
			"height": 24.39340617494452,
			"seed": 646872697,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-17.57438556648872,
					24.39340617494452
				]
			]
		},
		{
			"type": "line",
			"version": 2528,
			"versionNonce": 282943127,
			"isDeleted": false,
			"id": "OD_dNGmyF9SvwbduKH5KC",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -201.68979756388072,
			"y": 395.1416343682264,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.99454839941563,
			"height": 15.596942345268781,
			"seed": 779714967,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.99454839941563,
					15.596942345268781
				]
			]
		},
		{
			"type": "line",
			"version": 2540,
			"versionNonce": 2099165785,
			"isDeleted": false,
			"id": "Cuwd9papPtRDj6xzE06FS",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -185.37628663711317,
			"y": 410.8568432480962,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 26.798604282604586,
			"height": 13.467248605026825,
			"seed": 822757209,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					26.798604282604586,
					-13.467248605026825
				]
			]
		},
		{
			"type": "line",
			"version": 2536,
			"versionNonce": 1963160503,
			"isDeleted": false,
			"id": "LlCldWzGo4fJNHeeotcL9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -208.89179933432092,
			"y": 353.16647703068065,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57.35920066094075,
			"height": 11.66969047451636,
			"seed": 1898133175,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					57.35920066094075,
					11.66969047451636
				]
			]
		},
		{
			"type": "rectangle",
			"version": 2843,
			"versionNonce": 1709705017,
			"isDeleted": false,
			"id": "-_kGk55OHgfn1wtrjJy3T",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.1875122815022081,
			"x": -196.0659704805677,
			"y": 345.53045233178113,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 34.330844028819804,
			"height": 11.842596955377553,
			"seed": 249164857,
			"groupIds": [
				"2LINwN0H6hvbGXp4CnwXp",
				"MpPNSdpNcx6pOD14uNUnN"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1962,
			"versionNonce": 1374282967,
			"isDeleted": false,
			"id": "cLWQnbQnv-G8-BxvAgZmX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -555.3379922179089,
			"y": 741.7995194496668,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.842282310966675,
			"height": 22.306896096418093,
			"seed": 1783875545,
			"groupIds": [
				"skkqvPmt8TTVnxTfxkXyf",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1960,
			"versionNonce": 95729689,
			"isDeleted": false,
			"id": "41Z_wGOPFLlzPoKvPrWEz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -563.3047408237725,
			"y": 749.235151481806,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 22.306896096418093,
			"height": 6.904515458415117,
			"seed": 1804598839,
			"groupIds": [
				"skkqvPmt8TTVnxTfxkXyf",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2775,
			"versionNonce": 1730490871,
			"isDeleted": false,
			"id": "-7h9u2pE_qcE9VwINEiOy",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -543.9134652217361,
			"y": 676.2585279904462,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40.464626893298025,
			"height": 37.24382598878419,
			"seed": 1413463513,
			"groupIds": [
				"3Tq-GnAppaIc_J90AoNyu",
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2839,
			"versionNonce": 1853377785,
			"isDeleted": false,
			"id": "30lknwrDPKEA6DnbNHJ7w",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -525.9831952109132,
			"y": 713.2959351165905,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 1.985529028194427,
			"height": 45.15183950374935,
			"seed": 1594255415,
			"groupIds": [
				"3Tq-GnAppaIc_J90AoNyu",
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.985529028194427,
					45.15183950374935
				]
			]
		},
		{
			"type": "line",
			"version": 2792,
			"versionNonce": 230284055,
			"isDeleted": false,
			"id": "8TsWVAoN79o8oSF_r2e_1",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -527.7916246953297,
			"y": 759.604153905301,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 17.873550431284457,
			"height": 27.53595314482596,
			"seed": 1226611385,
			"groupIds": [
				"3Tq-GnAppaIc_J90AoNyu",
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					17.873550431284457,
					27.53595314482596
				]
			]
		},
		{
			"type": "line",
			"version": 2769,
			"versionNonce": 666256857,
			"isDeleted": false,
			"id": "5hAKeco7-uhg1F-ib1X2J",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -530.334777366693,
			"y": 757.8214340438578,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 15.293120530138657,
			"height": 25.580737536909346,
			"seed": 1486506327,
			"groupIds": [
				"3Tq-GnAppaIc_J90AoNyu",
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-15.293120530138657,
					25.580737536909346
				]
			]
		},
		{
			"type": "line",
			"version": 2830,
			"versionNonce": 169631799,
			"isDeleted": false,
			"id": "kdUpgz9BybLHcNo42I6Qr",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -550.6668967256485,
			"y": 738.9531124990733,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 23.63109160299584,
			"height": 15.135591872898797,
			"seed": 1275779993,
			"groupIds": [
				"3Tq-GnAppaIc_J90AoNyu",
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					23.63109160299584,
					-15.135591872898797
				]
			]
		},
		{
			"type": "line",
			"version": 2873,
			"versionNonce": 2088903353,
			"isDeleted": false,
			"id": "E75pWAuYsDw5onsnoF_nL",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -527.5969546274047,
			"y": 722.9496001647216,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 16.905087962880472,
			"height": 20.14323748124963,
			"seed": 1934952055,
			"groupIds": [
				"3Tq-GnAppaIc_J90AoNyu",
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					16.905087962880472,
					20.14323748124963
				]
			]
		},
		{
			"type": "text",
			"version": 580,
			"versionNonce": 506544471,
			"isDeleted": false,
			"id": "fYfFhuk6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -542.6827259043063,
			"y": 692.3994948883019,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.66400146484375,
			"height": 15.6,
			"seed": 1564344441,
			"groupIds": [
				"36e6wjT7aIt_Zh5wfEImy",
				"1s-Y5AtH65kolOTLKfA-N"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1679055973346,
			"link": null,
			"locked": false,
			"fontSize": 13.392078821542718,
			"fontFamily": 1,
			"text": "ಠ_ಠ",
			"rawText": "ಠ_ಠ",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ಠ_ಠ"
		},
		{
			"type": "arrow",
			"version": 470,
			"versionNonce": 1828461463,
			"isDeleted": false,
			"id": "_jnOhHx9Cui5wQst9fzeu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -714.0559713800737,
			"y": 739.6526786157941,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 397.7777777777778,
			"height": 1588.888888888889,
			"seed": 1691709209,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679056144761,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "KAzX6hzbKxdvXBNb4W1Cs",
				"focus": -0.11554533063640163,
				"gap": 23.11423305088215
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-397.7777777777778,
					-2.2222222222221717
				],
				[
					-369.586844808284,
					-1553.3333333333333
				],
				[
					-286.66666666666663,
					-1588.888888888889
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 1748.087260632802,
		"scrollY": 1118.1250991619836,
		"zoom": {
			"value": 0.45
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%