![[Workflow d'un Retour à Domicile (RAD)]]

Dans le cadre d'un retour à domicile, il y a une étape importante qui est la détection de l'opportunité de mettre en place un accompagnement multiple pour un patient sortant : 
- Ouverture de [[Droits liés à la santé du patient sortant d'hospitalisation]]
- Orientation vers une association d'hébergement
- Mise en lien avec d'autres services sociaux (exemple : département)
- Mise en place d'une protection, type tutelle, curatelle, etc

Selon le schema [[Yaso Phase 1]], il n'est pas prévu de procéder à un calcul précis de l'éventuel reste à charge pour le patient. En effet, la complexité de la collecte des données requises a ce calcul (sécu, mutuelle, série de dispositifs complémentaires ou dépendants entre eux, sans compter la situation du patient) n'est pas un frein au déploiement de la solution Yaso. 
Cette position pourra être réévaluée ultérieurement. 

![[Yaso Phase 1]]