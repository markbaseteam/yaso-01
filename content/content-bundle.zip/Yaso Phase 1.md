---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Création RAD par CS ^yu25IiMA

Activation Yaso Casting ^jIhFIvug

Intervention sociale ? ^6Epq17Qk

Validation Casting ^2oJnxCKw

Sortie = fin Phase 1 Yaso ^bzzG9Lrg

Création RAD par AS ^WmdRCNqv

Création par API ^IrRMXmPW

N ^s9jme9sd

Y ^6uMnIGkW

Définition besoins du patient ^lbgy1kUM

Ouverture de droits ^2bZLez38

Orientation ^8OTZt1nA

Génération d'une fiche-info ^8So0Ayyz

AS dispo ? ^adxiSTuz

Y ^bmPIrZgO

N ^Cz8VwmLx

Création par DAC ^QMCWbrz5

Création Prado ^oEOrHpYU

Début Phase 2 Yaso ^S5laNphQ

Remontée signaux faibles ^FKeRptn0

Liens entre intervenants ^MHQ0sEBm

Modification des besoins du patient ^vSzqqaYz

Ré-hospit du patient ^74JNrg3T

Infirmier ou médecin traitant ou AS CLIC ^oPwSxCAz

Nouveaux besoins ^DZWkro9L

Besoins existants ^y0L0YFOa

Besoins inutiles ^T8AbzsyZ

Patient à domicile ^EuOVwn68

Décès ^CVsyl7AN

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.20",
	"elements": [
		{
			"type": "rectangle",
			"version": 484,
			"versionNonce": 129261030,
			"isDeleted": false,
			"id": "NzHyNbfrBXRmrgGjoAHQ-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -735.8787878787879,
			"y": -453.1515151515151,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 1809932539,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "yu25IiMA"
				},
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				}
			],
			"updated": 1678981195787,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 382,
			"versionNonce": 129114316,
			"isDeleted": false,
			"id": "yu25IiMA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -721.6387442386512,
			"y": -448.1515151515151,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 145.51991271972656,
			"height": 48,
			"seed": 1670366901,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779840,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création RAD \npar CS",
			"rawText": "Création RAD par CS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "NzHyNbfrBXRmrgGjoAHQ-",
			"originalText": "Création RAD par CS"
		},
		{
			"type": "rectangle",
			"version": 569,
			"versionNonce": 686239034,
			"isDeleted": false,
			"id": "B_bFo4BTtkcueEW9N0oAP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -500.3333333333335,
			"y": -452.6363636363637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 979691963,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "WmdRCNqv"
				},
				{
					"id": "BFAM6_AIx2OJEsUH5EkDe",
					"type": "arrow"
				}
			],
			"updated": 1678981197875,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 467,
			"versionNonce": 479601140,
			"isDeleted": false,
			"id": "WmdRCNqv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -486.09328969319677,
			"y": -447.6363636363637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 145.51991271972656,
			"height": 48,
			"seed": 973333365,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779840,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création RAD \npar AS",
			"rawText": "Création RAD par AS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "B_bFo4BTtkcueEW9N0oAP",
			"originalText": "Création RAD par AS"
		},
		{
			"type": "rectangle",
			"version": 758,
			"versionNonce": 2005394342,
			"isDeleted": false,
			"id": "ZYXreMGpuENjDcit2qZdV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -2.999999999999659,
			"y": -457.6666666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 2131486683,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "IrRMXmPW"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				}
			],
			"updated": 1678980921169,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 697,
			"versionNonce": 952903500,
			"isDeleted": false,
			"id": "IrRMXmPW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 16.480049133301122,
			"y": -452.6666666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 135.03990173339844,
			"height": 48,
			"seed": 904615765,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779840,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création par \nAPI",
			"rawText": "Création par API",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ZYXreMGpuENjDcit2qZdV",
			"originalText": "Création par API"
		},
		{
			"type": "rectangle",
			"version": 1110,
			"versionNonce": 556900070,
			"isDeleted": false,
			"id": "h-dptHX8SFnNUiBMEdZjL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.515151515151,
			"y": 110.81818181818176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 867244282,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "oEOrHpYU"
				},
				{
					"id": "b9UoAtbwmNe5QRxebIemA",
					"type": "arrow"
				}
			],
			"updated": 1678982015226,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1043,
			"versionNonce": 652591988,
			"isDeleted": false,
			"id": "oEOrHpYU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -572.9450907851706,
			"y": 127.81818181818176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 150.85987854003906,
			"height": 24,
			"seed": 1849985958,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création Prado",
			"rawText": "Création Prado",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "h-dptHX8SFnNUiBMEdZjL",
			"originalText": "Création Prado"
		},
		{
			"type": "rectangle",
			"version": 1587,
			"versionNonce": 249425850,
			"isDeleted": false,
			"id": "gxL-DKMyjIMlXMJhDjepf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -555.1212121212113,
			"y": -27.439393939393824,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 801448283,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "QMCWbrz5"
				},
				{
					"id": "oK-Zk-4GXqz1CZZOUgUk0",
					"type": "arrow"
				}
			],
			"updated": 1678981875531,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1524,
			"versionNonce": 1977703884,
			"isDeleted": false,
			"id": "QMCWbrz5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -535.6411629879105,
			"y": -22.439393939393824,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 135.03990173339844,
			"height": 48,
			"seed": 1939633621,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Création par \nDAC",
			"rawText": "Création par DAC",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "gxL-DKMyjIMlXMJhDjepf",
			"originalText": "Création par DAC"
		},
		{
			"type": "rectangle",
			"version": 1305,
			"versionNonce": 1695362682,
			"isDeleted": false,
			"id": "svKVjGGJ-L36LKHMoRXSC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -91.53354978354963,
			"y": -2.9274891774895195,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 476426581,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "2bZLez38"
				},
				{
					"id": "Q3dWcUrpYCeifMjJPRcFs",
					"type": "arrow"
				},
				{
					"id": "g7X7bj1MM0cG4QezVgJnW",
					"type": "arrow"
				}
			],
			"updated": 1678981233208,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1217,
			"versionNonce": 1506096372,
			"isDeleted": false,
			"id": "2bZLez38",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.73348569663557,
			"y": 2.0725108225104805,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 140.39987182617188,
			"height": 48,
			"seed": 185105019,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ouverture de \ndroits",
			"rawText": "Ouverture de droits",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "svKVjGGJ-L36LKHMoRXSC",
			"originalText": "Ouverture de droits"
		},
		{
			"type": "rectangle",
			"version": 1013,
			"versionNonce": 1466718458,
			"isDeleted": false,
			"id": "WCMyvQ1bJyak7d6_2JVm-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -206.73809523809507,
			"y": -85.98917748917734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 35,
			"seed": 55890389,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "8OTZt1nA"
				},
				{
					"id": "xhjGwgM0meYnczQnWTqTN",
					"type": "arrow"
				}
			],
			"updated": 1678980951785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 940,
			"versionNonce": 2014037068,
			"isDeleted": false,
			"id": "8OTZt1nA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -173.99804396856382,
			"y": -80.48917748917734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 108.5198974609375,
			"height": 24,
			"seed": 645505531,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Orientation",
			"rawText": "Orientation",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "WCMyvQ1bJyak7d6_2JVm-",
			"originalText": "Orientation"
		},
		{
			"type": "rectangle",
			"version": 729,
			"versionNonce": 1116652138,
			"isDeleted": false,
			"id": "hqTn7LaTJ7T-zlDGw7yux",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 184.47619047619065,
			"y": -4.761904761904873,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 1970034075,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "jIhFIvug"
				},
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "4fO_N5MmZS09UAYqEKuA-",
					"type": "arrow"
				},
				{
					"id": "RicfoWaBRJbtriBVjp76c",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"id": "vJRuzIxN1TalXOv6orNiR",
					"type": "arrow"
				},
				{
					"id": "CdhaEI8GWibS-dIuwPjM5",
					"type": "arrow"
				}
			],
			"updated": 1678983405136,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 618,
			"versionNonce": 851080820,
			"isDeleted": false,
			"id": "jIhFIvug",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 194.3062533424016,
			"y": 4.738095238095127,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 154.33987426757812,
			"height": 48,
			"seed": 643933589,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Activation Yaso\nCasting",
			"rawText": "Activation Yaso Casting",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "hqTn7LaTJ7T-zlDGw7yux",
			"originalText": "Activation Yaso Casting"
		},
		{
			"type": "rectangle",
			"version": 1010,
			"versionNonce": 878979514,
			"isDeleted": false,
			"id": "EoY9T2Tw_jR-p9BwqysUh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -711.2164502164502,
			"y": 319.2813852813854,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 1888800955,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "lbgy1kUM"
				},
				{
					"id": "4fO_N5MmZS09UAYqEKuA-",
					"type": "arrow"
				},
				{
					"id": "g7X7bj1MM0cG4QezVgJnW",
					"type": "arrow"
				}
			],
			"updated": 1678982378572,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 961,
			"versionNonce": 1160075980,
			"isDeleted": false,
			"id": "lbgy1kUM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -679.3963971158643,
			"y": 324.2813852813854,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 110.35989379882812,
			"height": 72,
			"seed": 745139317,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Définition \nbesoins du \npatient",
			"rawText": "Définition besoins du patient",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "EoY9T2Tw_jR-p9BwqysUh",
			"originalText": "Définition besoins du patient"
		},
		{
			"type": "rectangle",
			"version": 1767,
			"versionNonce": 185995578,
			"isDeleted": false,
			"id": "iRh1_lu43TI20eWpk2IeJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 652.5714285714287,
			"y": -294.4761904761904,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 2117219323,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "4fO_N5MmZS09UAYqEKuA-",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "8So0Ayyz"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				}
			],
			"updated": 1678982129589,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1715,
			"versionNonce": 244025332,
			"isDeleted": false,
			"id": "8So0Ayyz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 666.5515082223076,
			"y": -284.9761904761904,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 146.0398406982422,
			"height": 48,
			"seed": 1547132213,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Génération \nd'une fiche-info",
			"rawText": "Génération d'une fiche-info",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "iRh1_lu43TI20eWpk2IeJ",
			"originalText": "Génération d'une fiche-info"
		},
		{
			"type": "rectangle",
			"version": 988,
			"versionNonce": 1291706342,
			"isDeleted": false,
			"id": "aLZfsUiZAto4QSYf0IM5N",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 408.38095238095286,
			"y": -293.52380952380923,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 67,
			"seed": 931195637,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "2oJnxCKw"
				},
				{
					"id": "ZsvmKZlMqpaCf_NLq5u7a",
					"type": "arrow"
				},
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				}
			],
			"updated": 1678982126504,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 920,
			"versionNonce": 398991692,
			"isDeleted": false,
			"id": "2oJnxCKw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 443.3109908331013,
			"y": -284.02380952380923,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104.13992309570312,
			"height": 48,
			"seed": 764357339,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Validation \nCasting",
			"rawText": "Validation Casting",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "aLZfsUiZAto4QSYf0IM5N",
			"originalText": "Validation Casting"
		},
		{
			"type": "rectangle",
			"version": 990,
			"versionNonce": 1775330742,
			"isDeleted": false,
			"id": "xrUNCIDj-kakB_4x-0pGn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 651.9047619047619,
			"y": -118.80952380952391,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 2139941845,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "bzzG9Lrg"
				},
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				}
			],
			"updated": 1678982438149,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 948,
			"versionNonce": 1094609268,
			"isDeleted": false,
			"id": "bzzG9Lrg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 674.2748104277111,
			"y": -113.80952380952391,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 129.25990295410156,
			"height": 48,
			"seed": 1021847547,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sortie = fin \nPhase 1 Yaso",
			"rawText": "Sortie = fin Phase 1 Yaso",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "xrUNCIDj-kakB_4x-0pGn",
			"originalText": "Sortie = fin Phase 1 Yaso"
		},
		{
			"type": "rectangle",
			"version": 1376,
			"versionNonce": 206151216,
			"isDeleted": false,
			"id": "foMBPgPTV3cTok5uHnqOO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -82.7106227106226,
			"y": 496.83150183150155,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 1357341418,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "S5laNphQ"
				}
			],
			"updated": 1678987795204,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1359,
			"versionNonce": 1196300236,
			"isDeleted": false,
			"id": "S5laNphQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -77.32056228581791,
			"y": 501.83150183150155,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 163.21987915039062,
			"height": 48,
			"seed": 501487798,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Début Phase 2 \nYaso",
			"rawText": "Début Phase 2 Yaso",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "foMBPgPTV3cTok5uHnqOO",
			"originalText": "Début Phase 2 Yaso"
		},
		{
			"type": "rectangle",
			"version": 1656,
			"versionNonce": 2054453110,
			"isDeleted": false,
			"id": "fyIvJUCPq_l25ybhCqURG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 618.6996336996342,
			"y": 348.8827838827835,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 991548714,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "vSzqqaYz"
				},
				{
					"id": "GGZid3HD5_FG-rVQpNKVp",
					"type": "arrow"
				},
				{
					"id": "YDN7s-iyHta5DhfyqePqg",
					"type": "arrow"
				},
				{
					"id": "qUiUSUYteXtsNRLzfiDZ8",
					"type": "arrow"
				},
				{
					"id": "MiguK1tbYs2rU8VIPMGpN",
					"type": "arrow"
				}
			],
			"updated": 1678983560193,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1671,
			"versionNonce": 773397236,
			"isDeleted": false,
			"id": "vSzqqaYz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 626.2397109091069,
			"y": 353.8827838827835,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 158.9198455810547,
			"height": 72,
			"seed": 2079910518,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Modification des\nbesoins du \npatient",
			"rawText": "Modification des besoins du patient",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "fyIvJUCPq_l25ybhCqURG",
			"originalText": "Modification des besoins du patient"
		},
		{
			"type": "rectangle",
			"version": 1631,
			"versionNonce": 124230442,
			"isDeleted": false,
			"id": "UPsenHGb4DvqMrZ2FV3lR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 332.03296703296724,
			"y": 228.88278388278349,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 763172522,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"id": "GGZid3HD5_FG-rVQpNKVp",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "DZWkro9L"
				},
				{
					"id": "YDN7s-iyHta5DhfyqePqg",
					"type": "arrow"
				},
				{
					"id": "3VHRZcJZAH4HV9am35WHz",
					"type": "arrow"
				}
			],
			"updated": 1678983408145,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1664,
			"versionNonce": 802242124,
			"isDeleted": false,
			"id": "DZWkro9L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 367.70301097827974,
			"y": 245.88278388278349,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 102.659912109375,
			"height": 48,
			"seed": 1166311670,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Nouveaux \nbesoins",
			"rawText": "Nouveaux besoins",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "UPsenHGb4DvqMrZ2FV3lR",
			"originalText": "Nouveaux besoins"
		},
		{
			"type": "rectangle",
			"version": 1732,
			"versionNonce": 714693046,
			"isDeleted": false,
			"id": "tUfQk9Wog0KFFGm4-TVpx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 498.69963369963443,
			"y": 140.54945054945023,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 590150390,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"id": "GGZid3HD5_FG-rVQpNKVp",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "y0L0YFOa"
				},
				{
					"id": "qUiUSUYteXtsNRLzfiDZ8",
					"type": "arrow"
				},
				{
					"id": "92um8CfjkTelr9AJL6UHd",
					"type": "arrow"
				}
			],
			"updated": 1678983411060,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1779,
			"versionNonce": 1604426868,
			"isDeleted": false,
			"id": "y0L0YFOa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 538.9196806967047,
			"y": 157.54945054945023,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 93.55990600585938,
			"height": 48,
			"seed": 778884970,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Besoins \nexistants",
			"rawText": "Besoins existants",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "tUfQk9Wog0KFFGm4-TVpx",
			"originalText": "Besoins existants"
		},
		{
			"type": "rectangle",
			"version": 1819,
			"versionNonce": 1618349238,
			"isDeleted": false,
			"id": "TenO786oYnvGD4bfQpvPc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 702.0329670329675,
			"y": 63.88278388278371,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 2109095658,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"id": "GGZid3HD5_FG-rVQpNKVp",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "T8AbzsyZ"
				},
				{
					"id": "MiguK1tbYs2rU8VIPMGpN",
					"type": "arrow"
				},
				{
					"id": "j3cGpMjp48uBWGE5KL785",
					"type": "arrow"
				}
			],
			"updated": 1678983415649,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1895,
			"versionNonce": 439063756,
			"isDeleted": false,
			"id": "T8AbzsyZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 714.1230472941979,
			"y": 92.88278388278371,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 149.81983947753906,
			"height": 24,
			"seed": 251722934,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Besoins inutiles",
			"rawText": "Besoins inutiles",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "TenO786oYnvGD4bfQpvPc",
			"originalText": "Besoins inutiles"
		},
		{
			"type": "rectangle",
			"version": 1579,
			"versionNonce": 644956918,
			"isDeleted": false,
			"id": "FH5Ns_QG43QLOvegxUWnV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 598.4432234432237,
			"y": 489.3956043956041,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 513983542,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "oPwSxCAz"
				},
				{
					"id": "GGZid3HD5_FG-rVQpNKVp",
					"type": "arrow"
				},
				{
					"id": "vFXCxfM-ZQc23bATrkbum",
					"type": "arrow"
				}
			],
			"updated": 1678983717621,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1640,
			"versionNonce": 530443764,
			"isDeleted": false,
			"id": "oPwSxCAz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 603.4632887508409,
			"y": 494.3956043956041,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 163.95986938476562,
			"height": 72,
			"seed": 620970538,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Infirmier ou \nmédecin traitant\nou AS CLIC",
			"rawText": "Infirmier ou médecin traitant ou AS CLIC",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "FH5Ns_QG43QLOvegxUWnV",
			"originalText": "Infirmier ou médecin traitant ou AS CLIC"
		},
		{
			"type": "rectangle",
			"version": 1994,
			"versionNonce": 1171618358,
			"isDeleted": false,
			"id": "VWURcppplGAofCIiJWhzH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 181.52014652014657,
			"y": 384.0109890109884,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 1950254314,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "74JNrg3T"
				}
			],
			"updated": 1678983743761,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 2036,
			"versionNonce": 603396940,
			"isDeleted": false,
			"id": "74JNrg3T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 201.42020908118172,
			"y": 401.0109890109884,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 134.1998748779297,
			"height": 48,
			"seed": 1485313718,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ré-hospit du \npatient",
			"rawText": "Ré-hospit du patient",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "VWURcppplGAofCIiJWhzH",
			"originalText": "Ré-hospit du patient"
		},
		{
			"type": "rectangle",
			"version": 1838,
			"versionNonce": 2134711350,
			"isDeleted": false,
			"id": "SLUc6p7y5S5dcQwqFRGHc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 358.186813186814,
			"y": 542.3443223443221,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 560112694,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "EuOVwn68"
				},
				{
					"id": "vFXCxfM-ZQc23bATrkbum",
					"type": "arrow"
				},
				{
					"id": "3Q7Cg_4hiWTDQET-SpJjn",
					"type": "arrow"
				}
			],
			"updated": 1678983722618,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1899,
			"versionNonce": 252972916,
			"isDeleted": false,
			"id": "EuOVwn68",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 392.23685438554446,
			"y": 559.3443223443221,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 105.89991760253906,
			"height": 48,
			"seed": 380723754,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Patient à \ndomicile",
			"rawText": "Patient à domicile",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "SLUc6p7y5S5dcQwqFRGHc",
			"originalText": "Patient à domicile"
		},
		{
			"type": "rectangle",
			"version": 1911,
			"versionNonce": 567557622,
			"isDeleted": false,
			"id": "kk02AUvPlFq8VUq7UaSUL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 59.85347985348062,
			"y": 597.3443223443219,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 82,
			"seed": 1466548458,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "CVsyl7AN"
				}
			],
			"updated": 1678983729285,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1993,
			"versionNonce": 663605708,
			"isDeleted": false,
			"id": "CVsyl7AN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 115.66350030025797,
			"y": 626.3443223443219,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 62.37995910644531,
			"height": 24,
			"seed": 2109643446,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Décès",
			"rawText": "Décès",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "kk02AUvPlFq8VUq7UaSUL",
			"originalText": "Décès"
		},
		{
			"type": "rectangle",
			"version": 1370,
			"versionNonce": 1432775926,
			"isDeleted": false,
			"id": "T1HEaM3ddqCNVeydFcg5n",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 583.5714285714288,
			"y": 624.5238095238092,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 122419318,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "FKeRptn0"
				},
				{
					"id": "3Q7Cg_4hiWTDQET-SpJjn",
					"type": "arrow"
				}
			],
			"updated": 1678983719070,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1378,
			"versionNonce": 1045037300,
			"isDeleted": false,
			"id": "FKeRptn0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 597.9714987618585,
			"y": 629.5238095238092,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 145.19985961914062,
			"height": 48,
			"seed": 1575383530,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Remontée \nsignaux faibles",
			"rawText": "Remontée signaux faibles",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "T1HEaM3ddqCNVeydFcg5n",
			"originalText": "Remontée signaux faibles"
		},
		{
			"type": "rectangle",
			"version": 1365,
			"versionNonce": 1888046506,
			"isDeleted": false,
			"id": "9Yz3ALfIOcij5KaMSYDfZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -326.42857142857133,
			"y": 537.6007326007325,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 58,
			"seed": 1431802218,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-QwkH20PZPcRlsZv_ixcn",
					"type": "arrow"
				},
				{
					"id": "dk97D9FPiFR2MGG87rTzm",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "MHQ0sEBm"
				}
			],
			"updated": 1678983734866,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1408,
			"versionNonce": 604616780,
			"isDeleted": false,
			"id": "MHQ0sEBm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -299.49851771763383,
			"y": 542.6007326007325,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 120.139892578125,
			"height": 48,
			"seed": 2058621494,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Liens entre \nintervenants",
			"rawText": "Liens entre intervenants",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "9Yz3ALfIOcij5KaMSYDfZ",
			"originalText": "Liens entre intervenants"
		},
		{
			"type": "diamond",
			"version": 553,
			"versionNonce": 1082537830,
			"isDeleted": false,
			"id": "-uPEBVDClufWpCgDOPYUs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -737.4242424242425,
			"y": -216.66666666666663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 193,
			"height": 174,
			"seed": 2057449947,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6Epq17Qk"
				},
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "BFAM6_AIx2OJEsUH5EkDe",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				}
			],
			"updated": 1678980921170,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 431,
			"versionNonce": 1153811060,
			"isDeleted": false,
			"id": "6Epq17Qk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -683.2842048876214,
			"y": -165.66666666666663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 85.21992492675781,
			"height": 72,
			"seed": 1420604501,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779841,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Interven\ntion \nsociale ?",
			"rawText": "Intervention sociale ?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "-uPEBVDClufWpCgDOPYUs",
			"originalText": "Intervention sociale ?"
		},
		{
			"type": "diamond",
			"version": 794,
			"versionNonce": 920017574,
			"isDeleted": false,
			"id": "1nbbvTP019Y3zMtBsLQJu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -336.46969696969734,
			"y": -283.40476190476164,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 193,
			"height": 174,
			"seed": 499036181,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "9anXUgdGyjpTmP18qhR9R",
					"type": "arrow"
				},
				{
					"id": "ni2QzpTojnGKNLLscAgJy",
					"type": "arrow"
				},
				{
					"id": "BFAM6_AIx2OJEsUH5EkDe",
					"type": "arrow"
				},
				{
					"id": "RMyOfBscTSC30ql2aQEdX",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "adxiSTuz"
				},
				{
					"id": "h96XBQ4UWkleAq78MN9i_",
					"type": "arrow"
				},
				{
					"id": "vJRuzIxN1TalXOv6orNiR",
					"type": "arrow"
				}
			],
			"updated": 1678980921170,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 681,
			"versionNonce": 625266380,
			"isDeleted": false,
			"id": "adxiSTuz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -281.13965699167,
			"y": -220.40476190476164,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.83992004394531,
			"height": 48,
			"seed": 651413435,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779842,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "AS dispo\n?",
			"rawText": "AS dispo ?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "1nbbvTP019Y3zMtBsLQJu",
			"originalText": "AS dispo ?"
		},
		{
			"type": "arrow",
			"version": 1843,
			"versionNonce": 1624761844,
			"isDeleted": false,
			"id": "ZsvmKZlMqpaCf_NLq5u7a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 321.0719695455383,
			"y": -13.761904761904873,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 146.35879424048056,
			"height": 203.76190476190436,
			"seed": 1727232635,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 9,
				"focus": 0.17169373549883996
			},
			"endBinding": {
				"elementId": "aLZfsUiZAto4QSYf0IM5N",
				"gap": 9,
				"focus": -0.023201856148491885
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					146.35879424048056,
					-203.76190476190436
				]
			]
		},
		{
			"type": "arrow",
			"version": 2498,
			"versionNonce": 105842548,
			"isDeleted": false,
			"id": "-QwkH20PZPcRlsZv_ixcn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 591.1727471145855,
			"y": -253.58293654022745,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 47.48778140823731,
			"height": 0.6483697392300485,
			"seed": 814442523,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "aLZfsUiZAto4QSYf0IM5N",
				"gap": 8.791794733632628,
				"focus": 0.14797659031343838
			},
			"endBinding": {
				"elementId": "iRh1_lu43TI20eWpk2IeJ",
				"gap": 13.91090004860581,
				"focus": -0.27154758232270915
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					47.48778140823731,
					0.6483697392300485
				]
			]
		},
		{
			"type": "arrow",
			"version": 2636,
			"versionNonce": 57014516,
			"isDeleted": false,
			"id": "dk97D9FPiFR2MGG87rTzm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 743.3651833633764,
			"y": -214.76190476190465,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.3014917269233592,
			"height": 83.61904761904748,
			"seed": 1802836123,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "iRh1_lu43TI20eWpk2IeJ",
				"gap": 12.71428571428578,
				"focus": -0.06361234480056409
			},
			"endBinding": {
				"elementId": "xrUNCIDj-kakB_4x-0pGn",
				"gap": 12.333333333333258,
				"focus": -0.005366327770120938
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-3.3014917269233592,
					83.61904761904748
				]
			]
		},
		{
			"type": "arrow",
			"version": 2089,
			"versionNonce": 1708888308,
			"isDeleted": false,
			"id": "9anXUgdGyjpTmP18qhR9R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -649.142076944438,
			"y": -394.1515151515152,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2.72591514523765,
			"height": 181.08970984256334,
			"seed": 1966656571,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "NzHyNbfrBXRmrgGjoAHQ-",
				"gap": 1,
				"focus": 0.008175923315477868
			},
			"endBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 1,
				"focus": -0.04390243902439024
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					2.72591514523765,
					181.08970984256334
				]
			]
		},
		{
			"type": "arrow",
			"version": 2733,
			"versionNonce": 598037108,
			"isDeleted": false,
			"id": "ni2QzpTojnGKNLLscAgJy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -636.8100405201376,
			"y": -33.485484743848474,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.302523338403944,
			"height": 350.43353669190043,
			"seed": 223079477,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "s9jme9sd"
				}
			],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 10.06085278729509,
				"focus": -0.03324124457531012
			},
			"endBinding": {
				"elementId": "EoY9T2Tw_jR-p9BwqysUh",
				"gap": 2.333333333333428,
				"focus": -0.10164842755474358
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					3.302523338403944,
					350.43353669190043
				]
			]
		},
		{
			"type": "text",
			"version": 16,
			"versionNonce": 1498239988,
			"isDeleted": false,
			"id": "s9jme9sd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -641.5987736629473,
			"y": 129.73128360210174,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 24,
			"seed": 1256266107,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779842,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "N",
			"rawText": "N",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ni2QzpTojnGKNLLscAgJy",
			"originalText": "N"
		},
		{
			"type": "arrow",
			"version": 1753,
			"versionNonce": 1438311412,
			"isDeleted": false,
			"id": "BFAM6_AIx2OJEsUH5EkDe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -431.997047120679,
			"y": -393.6363636363637,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 168.32624929844576,
			"height": 192.03121478125598,
			"seed": 316656213,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "B_bFo4BTtkcueEW9N0oAP",
				"gap": 1,
				"focus": -0.0678969722069914
			},
			"endBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 16,
				"focus": -0.23271723377478049
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-168.32624929844576,
					192.03121478125598
				]
			]
		},
		{
			"type": "arrow",
			"version": 2593,
			"versionNonce": 983087988,
			"isDeleted": false,
			"id": "RMyOfBscTSC30ql2aQEdX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 77.06375677294372,
			"y": -398.6666666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187.57985284128333,
			"height": 380.2889143052402,
			"seed": 261857685,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962228,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ZYXreMGpuENjDcit2qZdV",
				"gap": 1,
				"focus": 0.21454075131711942
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 13.6158475995216,
				"focus": 0.15849067526329877
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					187.57985284128333,
					380.2889143052402
				]
			]
		},
		{
			"type": "arrow",
			"version": 3181,
			"versionNonce": 2116122356,
			"isDeleted": false,
			"id": "wxJ07Lq37C28Dl9wVhOiz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -538.1563740062902,
			"y": -143.86310858970648,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 197.6989849305861,
			"height": 37.354647533736625,
			"seed": 968780885,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6uMnIGkW"
				}
			],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "-uPEBVDClufWpCgDOPYUs",
				"gap": 14.740958021623143,
				"focus": 0.06001433988940333
			},
			"endBinding": {
				"elementId": "1nbbvTP019Y3zMtBsLQJu",
				"gap": 13.949858074507574,
				"focus": 0.04367644870664801
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					197.6989849305861,
					-37.354647533736625
				]
			]
		},
		{
			"type": "text",
			"version": 12,
			"versionNonce": 735647052,
			"isDeleted": false,
			"id": "6uMnIGkW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -444.466877573712,
			"y": -174.5404323565748,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.319992065429688,
			"height": 24,
			"seed": 1148685621,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408779842,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Y",
			"rawText": "Y",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "wxJ07Lq37C28Dl9wVhOiz",
			"originalText": "Y"
		},
		{
			"type": "arrow",
			"version": 2127,
			"versionNonce": 743287116,
			"isDeleted": false,
			"id": "4fO_N5MmZS09UAYqEKuA-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -527.1861471861472,
			"y": 342.75225148677043,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 755.6017316017319,
			"height": 266.84708649195505,
			"seed": 606533205,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "EoY9T2Tw_jR-p9BwqysUh",
				"gap": 10.030303030303003,
				"focus": -0.27833018378594293
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 13.667069756720252,
				"focus": -0.041597889799842754
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					509.6991341991343,
					-25.717619452138365
				],
				[
					755.6017316017319,
					-266.84708649195505
				]
			]
		},
		{
			"type": "ellipse",
			"version": 487,
			"versionNonce": 1809319206,
			"isDeleted": false,
			"id": "6HtuCLJMvT_QVHwWsV4oJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -272.91666666666663,
			"y": 146.5530303030302,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.619047619047592,
			"height": 25.714285714285666,
			"seed": 695418011,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "Q3dWcUrpYCeifMjJPRcFs",
					"type": "arrow"
				},
				{
					"id": "xhjGwgM0meYnczQnWTqTN",
					"type": "arrow"
				},
				{
					"id": "wxJ07Lq37C28Dl9wVhOiz",
					"type": "arrow"
				},
				{
					"id": "h96XBQ4UWkleAq78MN9i_",
					"type": "arrow"
				},
				{
					"id": "RicfoWaBRJbtriBVjp76c",
					"type": "arrow"
				},
				{
					"id": "g7X7bj1MM0cG4QezVgJnW",
					"type": "arrow"
				},
				{
					"id": "oK-Zk-4GXqz1CZZOUgUk0",
					"type": "arrow"
				},
				{
					"id": "b9UoAtbwmNe5QRxebIemA",
					"type": "arrow"
				}
			],
			"updated": 1678980938957,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 588,
			"versionNonce": 1505841578,
			"isDeleted": false,
			"id": "ZDcxvOmgRwzph1yMqc9yF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 420.41666666666674,
			"y": 61.553030303030084,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 27.619047619047592,
			"height": 25.714285714285666,
			"seed": 9698922,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "CdhaEI8GWibS-dIuwPjM5",
					"type": "arrow"
				},
				{
					"id": "3VHRZcJZAH4HV9am35WHz",
					"type": "arrow"
				},
				{
					"id": "92um8CfjkTelr9AJL6UHd",
					"type": "arrow"
				},
				{
					"id": "j3cGpMjp48uBWGE5KL785",
					"type": "arrow"
				}
			],
			"updated": 1678983434012,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 3508,
			"versionNonce": 420525388,
			"isDeleted": false,
			"id": "Q3dWcUrpYCeifMjJPRcFs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -247.10965005567078,
			"y": 145.6077851226926,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 154.11327718209174,
			"height": 109.91964071365054,
			"seed": 1485197243,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962228,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 5.038865544230551,
				"focus": -0.32385913708852365
			},
			"endBinding": {
				"elementId": "svKVjGGJ-L36LKHMoRXSC",
				"gap": 1.4628230900294255,
				"focus": 0.5873526492083172
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					154.11327718209174,
					-109.91964071365054
				]
			]
		},
		{
			"type": "arrow",
			"version": 2779,
			"versionNonce": 979643340,
			"isDeleted": false,
			"id": "xhjGwgM0meYnczQnWTqTN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -252.11470225956666,
			"y": 145.63158972040628,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 111.49340736617825,
			"height": 191.02348739906813,
			"seed": 192370805,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962228,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 2.4127994635446033,
				"focus": -0.06678306110842487
			},
			"endBinding": {
				"elementId": "WCMyvQ1bJyak7d6_2JVm-",
				"gap": 5.597279810515488,
				"focus": 0.0761428994787459
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					111.49340736617825,
					-191.02348739906813
				]
			]
		},
		{
			"type": "arrow",
			"version": 1724,
			"versionNonce": 1203069300,
			"isDeleted": false,
			"id": "g7X7bj1MM0cG4QezVgJnW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -567.8007766959092,
			"y": 308.1688311688316,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 299.63408317594127,
			"height": 136.12902637598242,
			"seed": 408160411,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "EoY9T2Tw_jR-p9BwqysUh",
				"gap": 11.112554112553767,
				"focus": -0.46176150885938627
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"focus": -0.45350070957135247,
				"gap": 2.381339098730564
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					179.81592821106074,
					-61.770562770563174
				],
				[
					299.63408317594127,
					-136.12902637598242
				]
			]
		},
		{
			"type": "arrow",
			"version": 1559,
			"versionNonce": 1178499188,
			"isDeleted": false,
			"id": "h96XBQ4UWkleAq78MN9i_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -258.282436313049,
			"y": -104.80775175091588,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.4608253863556797,
			"height": 237.13136039413217,
			"seed": 764902139,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "bmPIrZgO"
				}
			],
			"updated": 1679408962232,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1nbbvTP019Y3zMtBsLQJu",
				"gap": 15.676543357032173,
				"focus": 0.17591629265390202
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 14.348903889437539,
				"focus": -0.21949744804323437
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-3.4608253863556797,
					237.13136039413217
				]
			]
		},
		{
			"type": "text",
			"version": 14,
			"versionNonce": 665419596,
			"isDeleted": false,
			"id": "bmPIrZgO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -265.17284503894166,
			"y": 1.7579284461502027,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 10.319992065429688,
			"height": 24,
			"seed": 384356219,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679647824925,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Y",
			"rawText": "Y",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "h96XBQ4UWkleAq78MN9i_",
			"originalText": "Y"
		},
		{
			"type": "arrow",
			"version": 1700,
			"versionNonce": 1446988276,
			"isDeleted": false,
			"id": "vJRuzIxN1TalXOv6orNiR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -128.83687861773234,
			"y": -188.2534965380596,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 359.7598338750395,
			"height": 171.29198460468473,
			"seed": 130643573,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "Cz8VwmLx"
				}
			],
			"updated": 1679408962232,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1nbbvTP019Y3zMtBsLQJu",
				"gap": 16.75,
				"focus": -0.514508732902157
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 12.199607171470007,
				"focus": 0.35224134294014486
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					359.7598338750395,
					171.29198460468473
				]
			]
		},
		{
			"type": "text",
			"version": 10,
			"versionNonce": 693155316,
			"isDeleted": false,
			"id": "Cz8VwmLx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 44.60304350777568,
			"y": -114.60750423571724,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 24,
			"seed": 14916411,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1679408838619,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "N",
			"rawText": "N",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "vJRuzIxN1TalXOv6orNiR",
			"originalText": "N"
		},
		{
			"type": "arrow",
			"version": 598,
			"versionNonce": 692591092,
			"isDeleted": false,
			"id": "RicfoWaBRJbtriBVjp76c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.30945678361158,
			"y": 152.71803502607557,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 416.84458831874326,
			"height": 107.3374288668624,
			"seed": 833241979,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962228,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 2.6051961462544266,
				"focus": -0.21602502504898596
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 11.941058941058998,
				"focus": 0.1580394615813451
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					416.84458831874326,
					-107.3374288668624
				]
			]
		},
		{
			"type": "arrow",
			"version": 1889,
			"versionNonce": 1223716556,
			"isDeleted": false,
			"id": "oK-Zk-4GXqz1CZZOUgUk0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -432.47708413144267,
			"y": 38.73593073593099,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 153.70390917404075,
			"height": 109.4723967241473,
			"seed": 439549306,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962227,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "gxL-DKMyjIMlXMJhDjepf",
				"gap": 8.175324675324816,
				"focus": 0.1295957563563251
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 9.067807937873162,
				"focus": -0.17327116342937463
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					153.70390917404075,
					109.4723967241473
				]
			]
		},
		{
			"type": "arrow",
			"version": 1339,
			"versionNonce": 1017731148,
			"isDeleted": false,
			"id": "b9UoAtbwmNe5QRxebIemA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -402.2294372294372,
			"y": 135.7755785347214,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 127.05241252050877,
			"height": 22.151254977682413,
			"seed": 1881295206,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962227,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "h-dptHX8SFnNUiBMEdZjL",
				"gap": 8.285714285713823,
				"focus": -0.46765336801185725
			},
			"endBinding": {
				"elementId": "6HtuCLJMvT_QVHwWsV4oJ",
				"gap": 2.337484188077525,
				"focus": -0.10079040235677265
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					127.05241252050877,
					22.151254977682413
				]
			]
		},
		{
			"type": "arrow",
			"version": 1341,
			"versionNonce": 705296756,
			"isDeleted": false,
			"id": "GGZid3HD5_FG-rVQpNKVp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 706.7496897337737,
			"y": 483.5472860472859,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.06588325715642895,
			"height": 43.410256410256466,
			"seed": 1720527670,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "FH5Ns_QG43QLOvegxUWnV",
				"gap": 5.848318348318173,
				"focus": 0.24391020408024794
			},
			"endBinding": {
				"elementId": "fyIvJUCPq_l25ybhCqURG",
				"gap": 9.254245754245972,
				"focus": -0.013693764324584927
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.06588325715642895,
					-43.410256410256466
				]
			]
		},
		{
			"type": "arrow",
			"version": 915,
			"versionNonce": 407363700,
			"isDeleted": false,
			"id": "YDN7s-iyHta5DhfyqePqg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 613.1955732676122,
			"y": 338.69172329940227,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 97.4116904837291,
			"height": 35.52362710427093,
			"seed": 1830580406,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962230,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fyIvJUCPq_l25ybhCqURG",
				"gap": 11.582417582417577,
				"focus": 0.24003721290016505
			},
			"endBinding": {
				"elementId": "UPsenHGb4DvqMrZ2FV3lR",
				"gap": 9.750915750915794,
				"focus": -0.027463716744583692
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-97.4116904837291,
					-35.52362710427093
				]
			]
		},
		{
			"type": "arrow",
			"version": 1269,
			"versionNonce": 1039750004,
			"isDeleted": false,
			"id": "qUiUSUYteXtsNRLzfiDZ8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 669.5127938213999,
			"y": 330.6336996336993,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.05432613889843,
			"height": 101.66666666666663,
			"seed": 1039888682,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962230,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fyIvJUCPq_l25ybhCqURG",
				"gap": 18.249084249084206,
				"focus": 0.11912893744819936
			},
			"endBinding": {
				"elementId": "tUfQk9Wog0KFFGm4-TVpx",
				"gap": 6.417582417582423,
				"focus": 0.35905772434430255
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-87.05432613889843,
					-101.66666666666663
				]
			]
		},
		{
			"type": "arrow",
			"version": 1307,
			"versionNonce": 640288372,
			"isDeleted": false,
			"id": "MiguK1tbYs2rU8VIPMGpN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 735.9608161346815,
			"y": 338.6754911754911,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32.43329135440524,
			"height": 178.66666666666652,
			"seed": 2071083766,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962230,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fyIvJUCPq_l25ybhCqURG",
				"gap": 10.207292707292368,
				"focus": 0.22199216140011666
			},
			"endBinding": {
				"elementId": "TenO786oYnvGD4bfQpvPc",
				"gap": 14.12604062604089,
				"focus": 0.11257459777348952
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					32.43329135440524,
					-178.66666666666652
				]
			]
		},
		{
			"type": "arrow",
			"version": 151,
			"versionNonce": 1074753140,
			"isDeleted": false,
			"id": "CdhaEI8GWibS-dIuwPjM5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 408.82196082028565,
			"y": 63.854546719970756,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 35.91503441335931,
			"height": 8.575774692045108,
			"seed": 638390698,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ZDcxvOmgRwzph1yMqc9yF",
				"gap": 13.847036616747362,
				"focus": 0.3382441383148094
			},
			"endBinding": {
				"elementId": "hqTn7LaTJ7T-zlDGw7yux",
				"gap": 14.430735930735693,
				"focus": 0.04276637216997777
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-35.91503441335931,
					-8.575774692045108
				]
			]
		},
		{
			"type": "arrow",
			"version": 152,
			"versionNonce": 1927000564,
			"isDeleted": false,
			"id": "3VHRZcJZAH4HV9am35WHz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 401.9769756673011,
			"y": 213.96703296703276,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 37.35611378166459,
			"height": 120.51921958235629,
			"seed": 75788598,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962230,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "UPsenHGb4DvqMrZ2FV3lR",
				"gap": 14.91575091575072,
				"focus": -0.3448821078467715
			},
			"endBinding": {
				"elementId": "ZDcxvOmgRwzph1yMqc9yF",
				"gap": 6.793729028591411,
				"focus": -0.7658637109212101
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					37.35611378166459,
					-120.51921958235629
				]
			]
		},
		{
			"type": "arrow",
			"version": 167,
			"versionNonce": 1743176948,
			"isDeleted": false,
			"id": "92um8CfjkTelr9AJL6UHd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 567.8667713834764,
			"y": 123.96703296703276,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 113.93570167663353,
			"height": 37.32830000360087,
			"seed": 137790902,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962230,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "tUfQk9Wog0KFFGm4-TVpx",
				"gap": 16.582417582417463,
				"focus": 0.7444220105736901
			},
			"endBinding": {
				"elementId": "ZDcxvOmgRwzph1yMqc9yF",
				"gap": 9.65828592394762,
				"focus": 0.4235321716886866
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-113.93570167663353,
					-37.32830000360087
				]
			]
		},
		{
			"type": "arrow",
			"version": 188,
			"versionNonce": 227088372,
			"isDeleted": false,
			"id": "j3cGpMjp48uBWGE5KL785",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 687.9069264069263,
			"y": 86.64744012183404,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 234.65643103523274,
			"height": 18.461716302636503,
			"seed": 769695594,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962230,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TenO786oYnvGD4bfQpvPc",
				"gap": 14.126040626041117,
				"focus": 0.21484480116343302
			},
			"endBinding": {
				"elementId": "ZDcxvOmgRwzph1yMqc9yF",
				"gap": 6.305514456029886,
				"focus": -0.5984047489749698
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-234.65643103523274,
					-18.461716302636503
				]
			]
		},
		{
			"type": "arrow",
			"version": 362,
			"versionNonce": 382282868,
			"isDeleted": false,
			"id": "vFXCxfM-ZQc23bATrkbum",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dotted",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 544.5735930735934,
			"y": 570.1019739685776,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 39.99999999999966,
			"height": 16.687913739520127,
			"seed": 221618730,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "SLUc6p7y5S5dcQwqFRGHc",
				"gap": 12.386779886779436,
				"focus": 0.3651097640039658
			},
			"endBinding": {
				"elementId": "FH5Ns_QG43QLOvegxUWnV",
				"gap": 13.869630369630613,
				"focus": 0.24663739454158495
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					39.99999999999966,
					-16.687913739520127
				]
			]
		},
		{
			"type": "arrow",
			"version": 478,
			"versionNonce": 764911476,
			"isDeleted": false,
			"id": "3Q7Cg_4hiWTDQET-SpJjn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dotted",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 529.5735930735934,
			"y": 636.7689649015441,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.333333333333144,
			"height": 18.311977639631095,
			"seed": 522802474,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1679408962231,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "SLUc6p7y5S5dcQwqFRGHc",
				"gap": 12.424642557222,
				"focus": 0.22843403927057593
			},
			"endBinding": {
				"elementId": "T1HEaM3ddqCNVeydFcg5n",
				"gap": 10.66450216450221,
				"focus": -0.6512387761420814
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					43.333333333333144,
					18.311977639631095
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dotted",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": null,
		"scrollX": 1210.6956376956375,
		"scrollY": 1025.071428571429,
		"zoom": {
			"value": 0.4
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%